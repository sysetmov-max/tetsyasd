﻿// Decompiled with JetBrains decompiler
// Type: TELAPOS_UID_BYPASS.Form1
// Assembly: ALECRIN_BYPASS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 740F77D7-0E85-4933-8B02-AA9B06E69548
// Assembly location: C:\Users\Systemov\Desktop\Release\Telapos Bypass.exe

using Guna.UI2.WinForms;
using Guna.UI2.WinForms.Enums;
using nxr;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

#nullable disable
namespace TELAPOS_UID_BYPASS;

public class Form1 : Form
{
  private static readonly HttpClient httpClient = new HttpClient();
  private const string ProxyUrl = "https://raw.githubusercontent.com/mmijan330/UID-BYPASS/refs/heads/main/Ip.txt";
  private const string CertUrl = "https://raw.githubusercontent.com/mmijan330/UID-BYPASS/refs/heads/main/c8750f0d.0";
  private const string EmbeddedResourceName = "TELAPOS_UID_BYPASS.c8750f0d.0";
  private const string CertHash = "c8750f0d";
  private bool dllStatus;
  private string adbPath;
  private Timer emulatorCheckTimer;
  private IContainer components;
  private Guna2BorderlessForm guna2BorderlessForm1;
  private Guna2DragControl guna2DragControl1;
  private Guna2DragControl guna2DragControl2;
  private Guna2DragControl guna2DragControl3;
  private Guna2DragControl guna2DragControl4;
  private Guna2DragControl guna2DragControl5;
  private Guna2DragControl guna2DragControl6;
  private Guna2DragControl guna2DragControl7;
  private Guna2DragControl guna2DragControl8;
  private Guna2DragControl guna2DragControl9;
  private Guna2Panel rootPanel;
  private Guna2Panel headerPanel;
  private Guna2Panel mainContentPanel;
  private Label appTitleLabel;
  private Guna2ControlBox guna2ControlBoxMinimize;
  private Guna2ControlBox guna2ControlBoxClose;
  private Guna2PictureBox guna2PictureBox3;
  private Label lblSettingsTitle;
  private Label lblTargetEmulator;
  private Label lblEncryption;
  private Label lblActionTitle;
  private Label label3;
  private Guna2ComboBox AdbCombo;
  private Guna2TextBox AdbTextBox;
  private Guna2GradientButton shayanButton1;
  private Guna2Button shayanButton2;
  private Guna2Button shayanButton4;
  private Guna2Button shayanButton5;
  private Guna2Button shayanButton3;

  public Form1(bool isDllLoaded)
  {
    try
    {
      this.adbPath = this.GetAdbPath();
    }
    catch (Exception ex)
    {
      int num = (int) MessageBox.Show(ex.Message, "ADB Não Encontrado", MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }
    this.InitializeComponent();
    this.Opacity = 0.85;
    try
    {
      this.Icon = Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location);
    }
    catch
    {
    }
    this.appTitleLabel.Font = Program.GetHeaderFont();
    this.FormClosed += new FormClosedEventHandler(this.Form1_FormClosed);
    this.dllStatus = isDllLoaded;
    if (this.dllStatus)
      NotificationForm.ShowNotification("Notificação", "DLL Conectada ✅", NotificationType.Success);
    else
      NotificationForm.ShowNotification("Notificação", "Modo Limitado ⚠️", NotificationType.Info);
    this.PopulateAdbCombo();
    this.PopulateAdbCombo1();
  }

  public Form1()
  {
    try
    {
      this.adbPath = this.GetAdbPath();
    }
    catch (Exception ex)
    {
      int num = (int) MessageBox.Show(ex.Message, "ADB Não Encontrado", MessageBoxButtons.OK, MessageBoxIcon.Hand);
      this.Close();
    }
    this.InitializeComponent();
    this.Opacity = 0.85;
    Timer timer = new Timer();
    timer.Interval = 200;
    timer.Tick += (EventHandler) ((s, e) =>
    {
      if (this.Opacity <= 0.85)
        return;
      this.Opacity = 0.85;
    });
    timer.Start();
    try
    {
      this.Icon = Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location);
    }
    catch
    {
    }
    this.appTitleLabel.Font = Program.GetHeaderFont();
    this.FormClosed += new FormClosedEventHandler(this.Form1_FormClosed);
    this.PopulateAdbCombo();
    this.PopulateAdbCombo1();
  }

  private Task<string> FetchOnlineProxy()
  {
    // ISSUE: variable of a compiler-generated type
    Form1.\u003CFetchOnlineProxy\u003Ec__async0 stateMachine;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder = AsyncTaskMethodBuilder<string>.Create();
    // ISSUE: reference to a compiler-generated field
    ref AsyncTaskMethodBuilder<string> local = ref stateMachine.\u0024builder;
    local.Start<Form1.\u003CFetchOnlineProxy\u003Ec__async0>(ref stateMachine);
    return local.Task;
  }

  private Task<string> FetchOnlineCert()
  {
    // ISSUE: variable of a compiler-generated type
    Form1.\u003CFetchOnlineCert\u003Ec__async1 stateMachine;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder = AsyncTaskMethodBuilder<string>.Create();
    // ISSUE: reference to a compiler-generated field
    ref AsyncTaskMethodBuilder<string> local = ref stateMachine.\u0024builder;
    local.Start<Form1.\u003CFetchOnlineCert\u003Ec__async1>(ref stateMachine);
    return local.Task;
  }

  private string GetMemuAdbPath()
  {
    string[] strArray = new string[4]
    {
      "C:\\Program Files\\Microvirt\\MEmu\\adb.exe",
      "C:\\Program Files (x86)\\Microvirt\\MEmu\\adb.exe",
      "D:\\Program Files\\Microvirt\\MEmu\\adb.exe",
      "D:\\Program Files (x86)\\Microvirt\\MEmu\\adb.exe"
    };
    foreach (string path in strArray)
    {
      if (File.Exists(path))
        return path;
    }
    return (string) null;
  }

  private bool IsProcessRunning(string[] processNames)
  {
    foreach (string processName in processNames)
    {
      if (Process.GetProcessesByName(processName).Length != 0)
        return true;
    }
    return false;
  }

  private void DetectRunningEmulator()
  {
    // ISSUE: variable of a compiler-generated type
    Form1.\u003CDetectRunningEmulator\u003Ec__async2 stateMachine;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024this = this;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder = AsyncVoidMethodBuilder.Create();
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder.Start<Form1.\u003CDetectRunningEmulator\u003Ec__async2>(ref stateMachine);
  }

  private void PopulateAdbCombo()
  {
    this.AdbCombo.Items.Clear();
    if (File.Exists("C:\\Program Files\\BlueStacks_nxt\\HD-Adb.exe"))
      this.AdbCombo.Items.Add((object) "BLUESTACKS");
    if (File.Exists("C:\\Program Files\\Bluestacks_msi5\\HD-Adb.exe"))
      this.AdbCombo.Items.Add((object) "MSI");
    if (this.GetMemuAdbPath() != null)
      this.AdbCombo.Items.Add((object) "MEMU");
    if (this.AdbCombo.Items.Count > 0)
      this.AdbCombo.SelectedIndex = 0;
    this.DetectRunningEmulator();
  }

  public void UpdateEmulatorStatus()
  {
    string str = "C:\\Program Files\\BlueStacks_nxt\\HD-Player.exe";
    if (!File.Exists(str))
      return;
    try
    {
      this.label3.Text = "Selecionar Emulador: " + FileVersionInfo.GetVersionInfo(str).FileVersion;
    }
    catch
    {
    }
  }

  private string ResolveAdbPath(string selectedEmulator)
  {
    string path1 = "C:\\Program Files\\Bluestacks_msi5\\HD-Adb.exe";
    string path2 = "C:\\Program Files\\BlueStacks_nxt\\HD-Adb.exe";
    if (selectedEmulator != null && selectedEmulator.Contains("MSI") && File.Exists(path1))
      return path1;
    if (selectedEmulator != null && selectedEmulator.Contains("BLUESTACKS") && File.Exists(path2))
      return path2;
    if (selectedEmulator != null && selectedEmulator.Contains("MEMU"))
    {
      string memuAdbPath = this.GetMemuAdbPath();
      if (memuAdbPath != null)
        return memuAdbPath;
    }
    throw new FileNotFoundException("No ADB executable found for the selected emulator.");
  }

  private string ExtractEmbeddedCert(string resourceName, string hash)
  {
    string path = Path.Combine(Path.GetTempPath(), hash + ".0");
    using (Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName))
    {
      using (FileStream destination = File.Create(path))
        manifestResourceStream.CopyTo((Stream) destination);
    }
    return path;
  }

  private string GetDefaultDeviceID(string selectedEmulator = null)
  {
    if (selectedEmulator != null)
      return selectedEmulator.Contains("MEMU") || selectedEmulator.Contains("Memu") ? "127.0.0.1:21503" : "127.0.0.1:5555";
    object selectedItem1 = this.AdbCombo.SelectedItem;
    if ((selectedItem1 == null ? 0 : (!selectedItem1.ToString().Contains("MEMU") ? 0 : 1)) == 0)
    {
      object selectedItem2 = this.AdbCombo.SelectedItem;
      if ((selectedItem2 == null ? 0 : (!selectedItem2.ToString().Contains("Memu") ? 0 : 1)) == 0)
        return "127.0.0.1:5555";
    }
    return "127.0.0.1:21503";
  }

  private void RunAdb(
    string exe,
    string args,
    out string stdout,
    out string stderr,
    string deviceId = null,
    string selectedEmulator = null)
  {
    if (deviceId == null)
      deviceId = this.GetDefaultDeviceID(selectedEmulator);
    using (Process process = Process.Start(new ProcessStartInfo()
    {
      FileName = exe,
      Arguments = $"-s {deviceId} {args}",
      RedirectStandardOutput = true,
      RedirectStandardError = true,
      UseShellExecute = false,
      CreateNoWindow = true
    }))
    {
      stdout = process.StandardOutput.ReadToEnd();
      stderr = process.StandardError.ReadToEnd();
      process.WaitForExit();
    }
  }

  private bool ConnectAdb(string adbExe, string selectedEmulator = null)
  {
    string defaultDeviceId = this.GetDefaultDeviceID(selectedEmulator);
    string stdout;
    this.RunAdb(adbExe, "connect " + defaultDeviceId, out stdout, out string _, defaultDeviceId, selectedEmulator);
    if (stdout.Contains("connected"))
      return true;
    NotificationForm.ShowNotification("Notificação", "Falha na Conexão ADB!", NotificationType.Failed);
    return false;
  }

  private bool FileExistsOnDevice(string adb, string path, string selectedEmulator)
  {
    string defaultDeviceId = this.GetDefaultDeviceID(selectedEmulator);
    string stdout;
    this.RunAdb(adb, $"shell \"[ -f {path} ] && echo yes || echo no\"", out stdout, out string _, defaultDeviceId, selectedEmulator);
    return stdout.Trim().Equals("yes", StringComparison.OrdinalIgnoreCase);
  }

  private void EditConfigs(string engineRootPath)
  {
    if (!Directory.Exists(engineRootPath))
      throw new Exception("Engine path not found.");
    foreach (string directory in Directory.GetDirectories(engineRootPath))
    {
      string fileName = Path.GetFileName(directory);
      foreach (string path in ((IEnumerable<string>) new string[3]
      {
        Path.Combine(directory, "Android.bstk.in"),
        Path.Combine(directory, fileName + ".bstk"),
        Path.Combine(directory, fileName + ".bstk-prev")
      }).Where<string>(new Func<string, bool>(File.Exists)))
      {
        string contents = Regex.Replace(Regex.Replace(File.ReadAllText(path, Encoding.UTF8), "(<HardDisk\\b[^>]*location\\s*=\\s*\"Root\\.vhd\"[^>]*type\\s*=\\s*\")Readonly(\"\\s*/?>)", "$1Normal$2", RegexOptions.IgnoreCase), "(<HardDisk\\b[^>]*location\\s*=\\s*\"Data\\.vhdx\"[^>]*type\\s*=\\s*\")Readonly(\"\\s*/?>)", "$1Normal$2", RegexOptions.IgnoreCase);
        File.WriteAllText(path, contents, Encoding.UTF8);
      }
    }
  }

  private string GetEmulatorIP()
  {
    try
    {
      using (Process process = Process.Start(new ProcessStartInfo()
      {
        FileName = this.adbPath,
        Arguments = "devices",
        RedirectStandardOutput = true,
        RedirectStandardError = true,
        UseShellExecute = false,
        CreateNoWindow = true
      }))
      {
        process.WaitForExit();
        string end = process.StandardOutput.ReadToEnd();
        char[] separator = new char[2]{ '\r', '\n' };
        foreach (string str in end.Split(separator, StringSplitOptions.RemoveEmptyEntries))
        {
          if (str.EndsWith("\tdevice"))
            return str.Split('\t')[0];
        }
      }
    }
    catch
    {
    }
    return "127.0.0.1:" + this.AdbTextBox.Text;
  }

  private Task<string> RunAdbCommandAsync(string exe, string arguments)
  {
    return Task.Run<string>((Func<string>) (() =>
    {
      try
      {
        using (Process process = Process.Start(new ProcessStartInfo()
        {
          FileName = exe,
          Arguments = arguments,
          RedirectStandardOutput = true,
          RedirectStandardError = true,
          UseShellExecute = false,
          CreateNoWindow = true
        }))
        {
          process.WaitForExit();
          string end1 = process.StandardOutput.ReadToEnd();
          string end2 = process.StandardError.ReadToEnd();
          return string.IsNullOrEmpty(end2) ? end1 : "Error: " + end2;
        }
      }
      catch (Exception ex)
      {
        return "Exception: " + ex.Message;
      }
    }));
  }

  private string RunAdbCommand(string exe, string arguments)
  {
    try
    {
      using (Process process = Process.Start(new ProcessStartInfo()
      {
        FileName = exe,
        Arguments = arguments,
        RedirectStandardOutput = true,
        RedirectStandardError = true,
        UseShellExecute = false,
        CreateNoWindow = true
      }))
      {
        process.WaitForExit();
        string end1 = process.StandardOutput.ReadToEnd();
        string end2 = process.StandardError.ReadToEnd();
        return string.IsNullOrEmpty(end2) ? end1 : "Error: " + end2;
      }
    }
    catch (Exception ex)
    {
      return "Exception: " + ex.Message;
    }
  }

  private void PopulateAdbCombo1()
  {
    if (File.Exists("C:\\Program Files\\Bluestacks_msi5\\HD-Adb.exe"))
      this.UpdateEmulatorStatus1();
    if (!File.Exists("C:\\Program Files\\BlueStacks_nxt\\HD-Adb.exe"))
      return;
    this.UpdateEmulatorStatus();
  }

  public void UpdateEmulatorStatus(string emulatorName = "BlueStacks NXT")
  {
    string str = "C:\\Program Files\\BlueStacks_nxt\\HD-Player.exe";
    if (!File.Exists(str))
      return;
    try
    {
      this.label3.Text = "Selecionar Emulador: " + FileVersionInfo.GetVersionInfo(str).FileVersion;
    }
    catch
    {
    }
  }

  public void UpdateEmulatorStatus1()
  {
    string str = "C:\\Program Files\\BlueStacks_msi5\\HD-Player.exe";
    if (!File.Exists(str))
      return;
    try
    {
      this.label3.Text = "Selecionar Emulador: " + FileVersionInfo.GetVersionInfo(str).FileVersion;
    }
    catch
    {
    }
  }

  private string GetAdbPath()
  {
    string[] strArray = new string[4]
    {
      "C:\\Program Files\\BlueStacks_msi5\\HD-Adb.exe",
      "C:\\Program Files\\BlueStacks_nxt\\HD-Adb.exe",
      this.GetMemuAdbPath() ?? string.Empty,
      "C:\\Android\\platform-tools\\adb.exe"
    };
    foreach (string path in strArray)
    {
      if (File.Exists(path))
        return path;
    }
    return string.Empty;
  }

  private void EmulatorCheckTimer_Tick(object sender, EventArgs e) => this.DetectRunningEmulator();

  private void shayanButton2_Click(object sender, EventArgs e)
  {
    // ISSUE: variable of a compiler-generated type
    Form1.\u003CshayanButton2_Click\u003Ec__async3 stateMachine;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024this = this;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder = AsyncVoidMethodBuilder.Create();
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder.Start<Form1.\u003CshayanButton2_Click\u003Ec__async3>(ref stateMachine);
  }

  private void shayanButton1_Click(object sender, EventArgs e)
  {
    // ISSUE: variable of a compiler-generated type
    Form1.\u003CshayanButton1_Click\u003Ec__async4 stateMachine;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024this = this;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder = AsyncVoidMethodBuilder.Create();
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder.Start<Form1.\u003CshayanButton1_Click\u003Ec__async4>(ref stateMachine);
  }

  private void Form1_Load(object sender, EventArgs e)
  {
    // ISSUE: variable of a compiler-generated type
    Form1.\u003CForm1_Load\u003Ec__async5 stateMachine;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024this = this;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder = AsyncVoidMethodBuilder.Create();
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder.Start<Form1.\u003CForm1_Load\u003Ec__async5>(ref stateMachine);
  }

  private void Form1_FormClosed(object sender, FormClosedEventArgs e)
  {
    try
    {
      DiscordRpcManager.Shutdown();
    }
    catch
    {
    }
    Environment.Exit(0);
  }

  private void shayanButton4_Click(object sender, EventArgs e)
  {
    try
    {
      object selectedItem1 = this.AdbCombo.SelectedItem;
      if ((selectedItem1 == null ? 0 : (!selectedItem1.ToString().Contains("Memu") ? 0 : 1)) != 0)
      {
        string[] strArray = new string[4]
        {
          "MEmu",
          "MEmuHeadless",
          "MEmuSVC",
          "MEmuManage"
        };
        foreach (string processName in strArray)
        {
          foreach (Process process in Process.GetProcessesByName(processName))
          {
            try
            {
              process.Kill();
              process.WaitForExit(2000);
            }
            catch
            {
            }
          }
        }
        string memuAdbPath = this.GetMemuAdbPath();
        if (memuAdbPath == null)
          return;
        string str = Path.Combine(Path.GetDirectoryName(memuAdbPath), "MEmu.exe");
        if (File.Exists(str))
        {
          Process.Start(str);
          NotificationForm.ShowNotification("Notificação", "MEmu Iniciado!", NotificationType.Success);
        }
        else
          NotificationForm.ShowNotification("Notificação", "Executável do MEmu não encontrado!", NotificationType.Error);
      }
      else
      {
        string[] strArray = new string[4]
        {
          "HD-Player",
          "HD-Adb",
          "HD-MultiInstanceManager",
          "BstkSVC"
        };
        foreach (string processName in strArray)
        {
          foreach (Process process in Process.GetProcessesByName(processName))
          {
            try
            {
              process.Kill();
              process.WaitForExit(2000);
            }
            catch
            {
            }
          }
        }
        object selectedItem2 = this.AdbCombo.SelectedItem;
        string str1 = (selectedItem2 == null ? 0 : (!selectedItem2.ToString().Contains("MSI") ? 0 : 1)) == 0 ? "C:\\ProgramData\\BlueStacks_nxt\\Engine" : "C:\\ProgramData\\Bluestacks_msi5\\Engine";
        this.EditConfigs(str1);
        string path1 = Path.Combine(str1, "Manager");
        if (Directory.Exists(path1))
        {
          foreach (string path2 in ((IEnumerable<string>) Directory.GetFiles(path1, "BstkServer.log")).Concat<string>((IEnumerable<string>) Directory.GetFiles(path1, "BstkServer.log.*")))
          {
            try
            {
              File.Delete(path2);
            }
            catch
            {
              try
              {
                using (new FileStream(path2, FileMode.Create, FileAccess.Write))
                  ;
              }
              catch
              {
              }
            }
          }
        }
        foreach (string directory in Directory.GetDirectories(str1))
        {
          string path3 = Path.Combine(directory, "Logs");
          if (Directory.Exists(path3))
          {
            foreach (string file in Directory.GetFiles(path3, "BstkCore.log*"))
            {
              try
              {
                File.Delete(file);
              }
              catch
              {
              }
            }
          }
        }
        NotificationForm.ShowNotification("Notificação", "Acesso Concedido!", NotificationType.Success);
        try
        {
          object selectedItem3 = this.AdbCombo.SelectedItem;
          string str2 = (selectedItem3 == null ? 0 : (!selectedItem3.ToString().Contains("MSI") ? 0 : 1)) == 0 ? "C:\\Program Files\\BlueStacks_nxt\\HD-Player.exe" : "C:\\Program Files\\BlueStacks_msi5\\HD-Player.exe";
          if (File.Exists(str2))
          {
            Process.Start(str2);
            NotificationForm.ShowNotification("Notificação", "Emulador Iniciado!", NotificationType.Success);
          }
          else
            NotificationForm.ShowNotification("Notificação", "Emulador não encontrado!", NotificationType.Error);
        }
        catch (Exception ex)
        {
        }
      }
    }
    catch (Exception ex)
    {
    }
  }

  private void shayanButton5_Click(object sender, EventArgs e)
  {
    // ISSUE: variable of a compiler-generated type
    Form1.\u003CshayanButton5_Click\u003Ec__async6 stateMachine;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024this = this;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder = AsyncVoidMethodBuilder.Create();
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder.Start<Form1.\u003CshayanButton5_Click\u003Ec__async6>(ref stateMachine);
  }

  private void shayanButton3_Click(object sender, EventArgs e)
  {
    // ISSUE: variable of a compiler-generated type
    Form1.\u003CshayanButton3_Click\u003Ec__async7 stateMachine;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024this = this;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder = AsyncVoidMethodBuilder.Create();
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder.Start<Form1.\u003CshayanButton3_Click\u003Ec__async7>(ref stateMachine);
  }

  private void AdbCombo_SelectedIndexChanged(object sender, EventArgs e)
  {
    switch (this.AdbCombo.SelectedItem?.ToString())
    {
      case "MSI":
        this.UpdateEmulatorStatus1();
        break;
      case "BLUESTACKS":
        this.UpdateEmulatorStatus();
        break;
      case "MEMU":
      case "Memu":
        this.label3.Text = "Selecionar Emulador: Executando";
        break;
    }
  }

  private void btnTabBypass_CheckedChanged(object sender, EventArgs e)
  {
  }

  private void btnTabInstaller_CheckedChanged(object sender, EventArgs e)
  {
  }

  private void btnTabPremium_CheckedChanged(object sender, EventArgs e)
  {
  }

  private void headerPanel_Paint(object sender, PaintEventArgs e)
  {
  }

  private void appTitleLabel_Click(object sender, EventArgs e)
  {
  }

  private void lblSetAttr1_Click(object sender, EventArgs e)
  {
  }

  private void lblSetAttr2_Click(object sender, EventArgs e)
  {
  }

  private void lblSetAttr3_Click(object sender, EventArgs e)
  {
  }

  private void bypassmenuPanel_Paint(object sender, PaintEventArgs e)
  {
  }

  private void lblActionTitle_Click(object sender, EventArgs e)
  {
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.components = (IContainer) new System.ComponentModel.Container();
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Form1));
    this.guna2BorderlessForm1 = new Guna2BorderlessForm(this.components);
    this.guna2DragControl1 = new Guna2DragControl(this.components);
    this.headerPanel = new Guna2Panel();
    this.appTitleLabel = new Label();
    this.guna2ControlBoxMinimize = new Guna2ControlBox();
    this.guna2ControlBoxClose = new Guna2ControlBox();
    this.rootPanel = new Guna2Panel();
    this.mainContentPanel = new Guna2Panel();
    this.guna2PictureBox3 = new Guna2PictureBox();
    this.lblSettingsTitle = new Label();
    this.lblTargetEmulator = new Label();
    this.lblEncryption = new Label();
    this.lblActionTitle = new Label();
    this.label3 = new Label();
    this.AdbCombo = new Guna2ComboBox();
    this.AdbTextBox = new Guna2TextBox();
    this.shayanButton1 = new Guna2GradientButton();
    this.shayanButton2 = new Guna2Button();
    this.shayanButton4 = new Guna2Button();
    this.shayanButton5 = new Guna2Button();
    this.shayanButton3 = new Guna2Button();
    this.guna2DragControl2 = new Guna2DragControl(this.components);
    this.guna2DragControl3 = new Guna2DragControl(this.components);
    this.guna2DragControl4 = new Guna2DragControl(this.components);
    this.guna2DragControl5 = new Guna2DragControl(this.components);
    this.guna2DragControl6 = new Guna2DragControl(this.components);
    this.guna2DragControl7 = new Guna2DragControl(this.components);
    this.guna2DragControl8 = new Guna2DragControl(this.components);
    this.guna2DragControl9 = new Guna2DragControl(this.components);
    this.headerPanel.SuspendLayout();
    this.rootPanel.SuspendLayout();
    this.mainContentPanel.SuspendLayout();
    ((ISupportInitialize) this.guna2PictureBox3).BeginInit();
    this.SuspendLayout();
    this.guna2BorderlessForm1.BorderRadius = 10;
    this.guna2BorderlessForm1.ContainerControl = (ContainerControl) this;
    this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6;
    this.guna2BorderlessForm1.ShadowColor = Color.FromArgb(40, 40, 45);
    this.guna2BorderlessForm1.TransparentWhileDrag = true;
    this.guna2DragControl1.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl1.TargetControl = (Control) this.headerPanel;
    this.guna2DragControl1.UseTransparentDrag = true;
    this.headerPanel.BackColor = Color.Transparent;
    this.headerPanel.Controls.Add((Control) this.appTitleLabel);
    this.headerPanel.Controls.Add((Control) this.guna2ControlBoxMinimize);
    this.headerPanel.Controls.Add((Control) this.guna2ControlBoxClose);
    this.headerPanel.Dock = DockStyle.Top;
    this.headerPanel.FillColor = Color.FromArgb(26, 26, 30);
    this.headerPanel.Location = new Point(0, 0);
    this.headerPanel.Name = "headerPanel";
    this.headerPanel.Size = new Size(460, 35);
    this.headerPanel.TabIndex = 1;
    this.appTitleLabel.AutoSize = true;
    this.appTitleLabel.Font = new Font("Segoe UI Semibold", 10f, FontStyle.Bold);
    this.appTitleLabel.ForeColor = Color.White;
    this.appTitleLabel.Location = new Point(15, 8);
    this.appTitleLabel.Name = "appTitleLabel";
    this.appTitleLabel.Size = new Size(151, 19);
    this.appTitleLabel.TabIndex = 0;
    this.appTitleLabel.Text = "TELAPOS BYPASS";
    this.guna2ControlBoxMinimize.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.guna2ControlBoxMinimize.Animated = true;
    this.guna2ControlBoxMinimize.ControlBoxType = ControlBoxType.MinimizeBox;
    this.guna2ControlBoxMinimize.FillColor = Color.Transparent;
    this.guna2ControlBoxMinimize.HoverState.FillColor = Color.FromArgb(45, 45, 50);
    this.guna2ControlBoxMinimize.IconColor = Color.White;
    this.guna2ControlBoxMinimize.Location = new Point(385, 0);
    this.guna2ControlBoxMinimize.Name = "guna2ControlBoxMinimize";
    this.guna2ControlBoxMinimize.Size = new Size(35, 35);
    this.guna2ControlBoxMinimize.TabIndex = 5;
    this.guna2ControlBoxClose.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.guna2ControlBoxClose.Animated = true;
    this.guna2ControlBoxClose.FillColor = Color.Transparent;
    this.guna2ControlBoxClose.HoverState.FillColor = Color.FromArgb(200, 0, 0);
    this.guna2ControlBoxClose.IconColor = Color.White;
    this.guna2ControlBoxClose.Location = new Point(420, 0);
    this.guna2ControlBoxClose.Name = "guna2ControlBoxClose";
    this.guna2ControlBoxClose.Size = new Size(35, 35);
    this.guna2ControlBoxClose.TabIndex = 4;
    this.rootPanel.Controls.Add((Control) this.mainContentPanel);
    this.rootPanel.Controls.Add((Control) this.headerPanel);
    this.rootPanel.Dock = DockStyle.Fill;
    this.rootPanel.FillColor = Color.FromArgb(18, 18, 20);
    this.rootPanel.Location = new Point(0, 0);
    this.rootPanel.Name = "rootPanel";
    this.rootPanel.Size = new Size(460, 240 /*0xF0*/);
    this.rootPanel.TabIndex = 0;
    this.mainContentPanel.BackColor = Color.Transparent;
    this.mainContentPanel.Controls.Add((Control) this.guna2PictureBox3);
    this.mainContentPanel.Controls.Add((Control) this.lblSettingsTitle);
    this.mainContentPanel.Controls.Add((Control) this.lblTargetEmulator);
    this.mainContentPanel.Controls.Add((Control) this.lblEncryption);
    this.mainContentPanel.Controls.Add((Control) this.lblActionTitle);
    this.mainContentPanel.Controls.Add((Control) this.label3);
    this.mainContentPanel.Controls.Add((Control) this.AdbCombo);
    this.mainContentPanel.Controls.Add((Control) this.AdbTextBox);
    this.mainContentPanel.Controls.Add((Control) this.shayanButton1);
    this.mainContentPanel.Controls.Add((Control) this.shayanButton2);
    this.mainContentPanel.Controls.Add((Control) this.shayanButton4);
    this.mainContentPanel.Controls.Add((Control) this.shayanButton5);
    this.mainContentPanel.Controls.Add((Control) this.shayanButton3);
    this.mainContentPanel.Dock = DockStyle.Fill;
    this.mainContentPanel.Location = new Point(0, 35);
    this.mainContentPanel.Name = "mainContentPanel";
    this.mainContentPanel.Size = new Size(460, 205);
    this.mainContentPanel.TabIndex = 3;
    this.guna2PictureBox3.Image = (Image) componentResourceManager.GetObject("guna2PictureBox3.Image");
    this.guna2PictureBox3.ImageRotate = 0.0f;
    this.guna2PictureBox3.Location = new Point(15, 30);
    this.guna2PictureBox3.Name = "guna2PictureBox3";
    this.guna2PictureBox3.Size = new Size(75, 75);
    this.guna2PictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
    this.guna2PictureBox3.TabIndex = 4;
    this.guna2PictureBox3.TabStop = false;
    this.lblSettingsTitle.AutoSize = true;
    this.lblSettingsTitle.Font = new Font("Segoe UI Semibold", 10.5f, FontStyle.Bold);
    this.lblSettingsTitle.ForeColor = Color.White;
    this.lblSettingsTitle.Location = new Point(20, 115);
    this.lblSettingsTitle.Name = "lblSettingsTitle";
    this.lblSettingsTitle.Size = new Size(62, 19);
    this.lblSettingsTitle.TabIndex = 0;
    this.lblSettingsTitle.Text = "Free Fire";
    this.lblTargetEmulator.AutoSize = true;
    this.lblTargetEmulator.Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold);
    this.lblTargetEmulator.ForeColor = Color.White;
    this.lblTargetEmulator.Location = new Point(15, 134);
    this.lblTargetEmulator.Name = "lblTargetEmulator";
    this.lblTargetEmulator.Size = new Size(82, 15);
    this.lblTargetEmulator.TabIndex = 1;
    this.lblTargetEmulator.Text = "Status: Offline";
    this.lblEncryption.AutoSize = true;
    this.lblEncryption.Font = new Font("Segoe UI", 8.5f);
    this.lblEncryption.ForeColor = Color.FromArgb(140, 140, 150);
    this.lblEncryption.Location = new Point(15, 150);
    this.lblEncryption.Name = "lblEncryption";
    this.lblEncryption.Size = new Size(67, 15);
    this.lblEncryption.TabIndex = 2;
    this.lblEncryption.Text = "Expira:";
    this.lblActionTitle.AutoSize = true;
    this.lblActionTitle.Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold);
    this.lblActionTitle.ForeColor = Color.FromArgb(0, 208 /*0xD0*/, 80 /*0x50*/);
    this.lblActionTitle.Location = new Point(15, 166);
    this.lblActionTitle.Name = "lblActionTitle";
    this.lblActionTitle.Size = new Size(77, 15);
    this.lblActionTitle.TabIndex = 6;
    this.lblActionTitle.Text = "100% Seguro";
    this.label3.AutoSize = true;
    this.label3.Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold);
    this.label3.ForeColor = Color.FromArgb(130, 130, 140);
    this.label3.Location = new Point(110, 12);
    this.label3.Name = "label3";
    this.label3.Size = new Size(119, 15);
    this.label3.TabIndex = 0;
    this.label3.Text = "Selecionar Emulador:";
    this.AdbCombo.BackColor = Color.Transparent;
    this.AdbCombo.BorderColor = Color.FromArgb(40, 40, 45);
    this.AdbCombo.BorderRadius = 5;
    this.AdbCombo.DrawMode = DrawMode.OwnerDrawFixed;
    this.AdbCombo.DropDownStyle = ComboBoxStyle.DropDownList;
    this.AdbCombo.FillColor = Color.FromArgb(26, 26, 30);
    this.AdbCombo.FocusedColor = Color.FromArgb(128 /*0x80*/, 0, (int) byte.MaxValue);
    this.AdbCombo.FocusedState.BorderColor = Color.FromArgb(128 /*0x80*/, 0, (int) byte.MaxValue);
    this.AdbCombo.Font = new Font("Segoe UI Semibold", 8.5f);
    this.AdbCombo.ForeColor = Color.White;
    this.AdbCombo.ItemHeight = 22;
    this.AdbCombo.Location = new Point(110, 30);
    this.AdbCombo.Name = "AdbCombo";
    this.AdbCombo.Size = new Size(180, 28);
    this.AdbCombo.TabIndex = 1;
    this.AdbCombo.SelectedIndexChanged += new EventHandler(this.AdbCombo_SelectedIndexChanged);
    this.AdbTextBox.BorderColor = Color.FromArgb(40, 40, 45);
    this.AdbTextBox.BorderRadius = 5;
    this.AdbTextBox.Cursor = Cursors.IBeam;
    this.AdbTextBox.DefaultText = "5555";
    this.AdbTextBox.FillColor = Color.FromArgb(26, 26, 30);
    this.AdbTextBox.FocusedState.BorderColor = Color.FromArgb(128 /*0x80*/, 0, (int) byte.MaxValue);
    this.AdbTextBox.Font = new Font("Segoe UI Semibold", 8.5f);
    this.AdbTextBox.ForeColor = Color.White;
    this.AdbTextBox.Location = new Point(295, 30);
    this.AdbTextBox.Name = "AdbTextBox";
    this.AdbTextBox.PlaceholderText = string.Empty;
    this.AdbTextBox.SelectedText = string.Empty;
    this.AdbTextBox.Size = new Size(150, 28);
    this.AdbTextBox.TabIndex = 2;
    this.AdbTextBox.TextAlign = HorizontalAlignment.Center;
    this.shayanButton1.BorderRadius = 6;
    this.shayanButton1.Cursor = Cursors.Hand;
    this.shayanButton1.FillColor = Color.FromArgb(128 /*0x80*/, 0, (int) byte.MaxValue);
    this.shayanButton1.FillColor2 = Color.FromArgb(85, 0, 180);
    this.shayanButton1.Font = new Font("Segoe UI Semibold", 9.5f, FontStyle.Bold);
    this.shayanButton1.ForeColor = Color.White;
    this.shayanButton1.HoverState.FillColor = Color.FromArgb(140, 20, (int) byte.MaxValue);
    this.shayanButton1.Location = new Point(110, 68);
    this.shayanButton1.Name = "shayanButton1";
    this.shayanButton1.Size = new Size(160 /*0xA0*/, 36);
    this.shayanButton1.TabIndex = 4;
    this.shayanButton1.Text = "Conectar";
    this.shayanButton1.Click += new EventHandler(this.shayanButton1_Click);
    this.shayanButton2.BorderColor = Color.FromArgb(40, 40, 45);
    this.shayanButton2.BorderRadius = 6;
    this.shayanButton2.BorderThickness = 1;
    this.shayanButton2.Cursor = Cursors.Hand;
    this.shayanButton2.FillColor = Color.FromArgb(26, 26, 30);
    this.shayanButton2.Font = new Font("Segoe UI Semibold", 9.5f, FontStyle.Bold);
    this.shayanButton2.ForeColor = Color.FromArgb(180, 180, 190);
    this.shayanButton2.HoverState.BorderColor = Color.FromArgb(128 /*0x80*/, 0, (int) byte.MaxValue);
    this.shayanButton2.HoverState.ForeColor = Color.White;
    this.shayanButton2.Location = new Point(280, 68);
    this.shayanButton2.Name = "shayanButton2";
    this.shayanButton2.Size = new Size(165, 36);
    this.shayanButton2.TabIndex = 5;
    this.shayanButton2.Text = "Desconectar";
    this.shayanButton2.Click += new EventHandler(this.shayanButton2_Click);
    this.shayanButton4.BorderColor = Color.FromArgb(40, 40, 45);
    this.shayanButton4.BorderRadius = 6;
    this.shayanButton4.BorderThickness = 1;
    this.shayanButton4.Cursor = Cursors.Hand;
    this.shayanButton4.FillColor = Color.FromArgb(26, 26, 30);
    this.shayanButton4.Font = new Font("Segoe UI Semibold", 9f, FontStyle.Bold);
    this.shayanButton4.ForeColor = Color.FromArgb(180, 180, 190);
    this.shayanButton4.HoverState.BorderColor = Color.FromArgb(128 /*0x80*/, 0, (int) byte.MaxValue);
    this.shayanButton4.HoverState.ForeColor = Color.White;
    this.shayanButton4.Location = new Point(110, 112 /*0x70*/);
    this.shayanButton4.Name = "shayanButton4";
    this.shayanButton4.Size = new Size(335, 32 /*0x20*/);
    this.shayanButton4.TabIndex = 6;
    this.shayanButton4.Text = "Autorizar Emulador / Abrir ou Fechar";
    this.shayanButton4.Click += new EventHandler(this.shayanButton4_Click);
    this.shayanButton5.BorderColor = Color.FromArgb(40, 40, 45);
    this.shayanButton5.BorderRadius = 6;
    this.shayanButton5.BorderThickness = 1;
    this.shayanButton5.Cursor = Cursors.Hand;
    this.shayanButton5.FillColor = Color.FromArgb(26, 26, 30);
    this.shayanButton5.Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold);
    this.shayanButton5.ForeColor = Color.FromArgb(180, 180, 190);
    this.shayanButton5.HoverState.BorderColor = Color.FromArgb(128 /*0x80*/, 0, (int) byte.MaxValue);
    this.shayanButton5.HoverState.ForeColor = Color.White;
    this.shayanButton5.Location = new Point(110, 152);
    this.shayanButton5.Name = "shayanButton5";
    this.shayanButton5.Size = new Size(160 /*0xA0*/, 32 /*0x20*/);
    this.shayanButton5.TabIndex = 7;
    this.shayanButton5.Text = "Instalar Certificado";
    this.shayanButton5.Click += new EventHandler(this.shayanButton5_Click);
    this.shayanButton3.BorderColor = Color.FromArgb(40, 40, 45);
    this.shayanButton3.BorderRadius = 6;
    this.shayanButton3.BorderThickness = 1;
    this.shayanButton3.Cursor = Cursors.Hand;
    this.shayanButton3.FillColor = Color.FromArgb(26, 26, 30);
    this.shayanButton3.Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold);
    this.shayanButton3.ForeColor = Color.FromArgb(180, 180, 190);
    this.shayanButton3.HoverState.BorderColor = Color.FromArgb(128 /*0x80*/, 0, (int) byte.MaxValue);
    this.shayanButton3.HoverState.ForeColor = Color.White;
    this.shayanButton3.Location = new Point(280, 152);
    this.shayanButton3.Name = "shayanButton3";
    this.shayanButton3.Size = new Size(165, 32 /*0x20*/);
    this.shayanButton3.TabIndex = 8;
    this.shayanButton3.Text = "Remover Certificado";
    this.shayanButton3.Click += new EventHandler(this.shayanButton3_Click);
    this.guna2DragControl2.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl2.TargetControl = (Control) this.rootPanel;
    this.guna2DragControl2.UseTransparentDrag = true;
    this.guna2DragControl3.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl3.TargetControl = (Control) this.mainContentPanel;
    this.guna2DragControl3.UseTransparentDrag = true;
    this.guna2DragControl4.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl4.TargetControl = (Control) this.appTitleLabel;
    this.guna2DragControl4.UseTransparentDrag = true;
    this.guna2DragControl5.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl5.TargetControl = (Control) this.guna2PictureBox3;
    this.guna2DragControl5.UseTransparentDrag = true;
    this.guna2DragControl6.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl6.TargetControl = (Control) this.lblSettingsTitle;
    this.guna2DragControl6.UseTransparentDrag = true;
    this.guna2DragControl7.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl7.TargetControl = (Control) this.lblTargetEmulator;
    this.guna2DragControl7.UseTransparentDrag = true;
    this.guna2DragControl8.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl8.TargetControl = (Control) this.lblEncryption;
    this.guna2DragControl8.UseTransparentDrag = true;
    this.guna2DragControl9.DockIndicatorTransparencyValue = 0.6;
    this.guna2DragControl9.TargetControl = (Control) this.lblActionTitle;
    this.guna2DragControl9.UseTransparentDrag = true;
    this.AutoScaleMode = AutoScaleMode.None;
    this.BackColor = Color.FromArgb(18, 18, 20);
    this.ClientSize = new Size(460, 240 /*0xF0*/);
    this.Controls.Add((Control) this.rootPanel);
    this.FormBorderStyle = FormBorderStyle.None;
    this.Name = nameof (Form1);
    this.StartPosition = FormStartPosition.CenterScreen;
    this.Text = "TELAPOS BYPASS";
    this.Load += new EventHandler(this.Form1_Load);
    this.headerPanel.ResumeLayout(false);
    this.headerPanel.PerformLayout();
    this.rootPanel.ResumeLayout(false);
    this.mainContentPanel.ResumeLayout(false);
    this.mainContentPanel.PerformLayout();
    ((ISupportInitialize) this.guna2PictureBox3).EndInit();
    this.ResumeLayout(false);
  }
}
