﻿// Decompiled with JetBrains decompiler
// Type: TELAPOS_UID_BYPASS.Program
// Assembly: ALECRIN_BYPASS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 740F77D7-0E85-4933-8B02-AA9B06E69548
// Assembly location: C:\Users\Systemov\Desktop\Release\Telapos Bypass.exe

using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace TELAPOS_UID_BYPASS;

internal static class Program
{
  public static Font GetHeaderFont() => new Font("Segoe UI", 11.25f, FontStyle.Bold);

  [STAThread]
  private static void Main()
  {
    Application.EnableVisualStyles();
    Application.SetCompatibleTextRenderingDefault(false);
    int num1;
    Application.ThreadException += (ThreadExceptionEventHandler) ((s, ex) => num1 = (int) MessageBox.Show($"Erro: {ex.Exception.Message}\n{ex.Exception.StackTrace}", "Erro Critico"));
    int num2;
    AppDomain.CurrentDomain.UnhandledException += (UnhandledExceptionEventHandler) ((s, ex) => num2 = (int) MessageBox.Show("Erro: " + ex.ExceptionObject.ToString(), "Erro Fatal"));
    try
    {
      DiscordRpcManager.Initialize();
    }
    catch
    {
    }
    bool isDllLoaded = false;
    try
    {
      using (SplashForm splashForm = new SplashForm())
      {
        int num3 = (int) splashForm.ShowDialog();
        isDllLoaded = splashForm.DllLoaded;
      }
    }
    catch (Exception ex)
    {
      int num4 = (int) MessageBox.Show("Erro na tela de carregamento:\n" + ex.Message, "Erro");
    }
    try
    {
      Form1 mainForm = new Form1(isDllLoaded);
      mainForm.FormClosed += (FormClosedEventHandler) ((s, e) =>
      {
        try
        {
          DiscordRpcManager.Shutdown();
        }
        catch
        {
        }
      });
      Application.Run((Form) mainForm);
    }
    catch (Exception ex)
    {
      int num5 = (int) MessageBox.Show($"Erro ao abrir menu principal:\n{ex.Message}\n\n{ex.StackTrace}", "Erro");
    }
  }
}
