﻿// Decompiled with JetBrains decompiler
// Type: ALECRIN_UID_BYPASS.Properties.Resources
// Assembly: ALECRIN_BYPASS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 740F77D7-0E85-4933-8B02-AA9B06E69548
// Assembly location: C:\Users\Systemov\Desktop\Release\Telapos Bypass.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

#nullable disable
namespace ALECRIN_UID_BYPASS.Properties;

[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "18.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
internal class Resources
{
  private static ResourceManager resourceMan;
  private static CultureInfo resourceCulture;

  internal Resources()
  {
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static ResourceManager ResourceManager
  {
    get
    {
      if (ALECRIN_UID_BYPASS.Properties.Resources.resourceMan == null)
        ALECRIN_UID_BYPASS.Properties.Resources.resourceMan = new ResourceManager("ALECRIN_UID_BYPASS.Properties.Resources", typeof (ALECRIN_UID_BYPASS.Properties.Resources).Assembly);
      return ALECRIN_UID_BYPASS.Properties.Resources.resourceMan;
    }
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static CultureInfo Culture
  {
    get => ALECRIN_UID_BYPASS.Properties.Resources.resourceCulture;
    set => ALECRIN_UID_BYPASS.Properties.Resources.resourceCulture = value;
  }
}
