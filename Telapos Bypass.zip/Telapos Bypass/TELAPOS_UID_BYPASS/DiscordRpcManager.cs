﻿// Decompiled with JetBrains decompiler
// Type: TELAPOS_UID_BYPASS.DiscordRpcManager
// Assembly: ALECRIN_BYPASS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 740F77D7-0E85-4933-8B02-AA9B06E69548
// Assembly location: C:\Users\Systemov\Desktop\Release\Telapos Bypass.exe

using System;
using System.IO;
using System.IO.Pipes;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

#nullable disable
namespace TELAPOS_UID_BYPASS;

public static class DiscordRpcManager
{
  public static string ClientId = "1520871468408508486";
  public static string DiscordInviteUrl = "https://discord.gg/telapos";
  public static string CurrentStateText = "Bypass Conectado";
  public static string LargeImage = "perfil";
  public static string LargeText = "TELAPOS BYPASS";
  private static readonly object _pipeLock = new object();
  private static NamedPipeClientStream _pipe;
  private static volatile bool _isConnected;
  private static volatile bool _isConnecting;
  private static long _startTimeUnix;
  private static CancellationTokenSource _readLoopCts;
  private static CancellationTokenSource _reconnectCts;
  private static readonly SemaphoreSlim _writeLock = new SemaphoreSlim(1, 1);
  private const int MaxPayloadSize = 65536 /*0x010000*/;

  private static void Log(string level, string message)
  {
    try
    {
      string str = Path.Combine(Path.GetTempPath(), "TelaposBypassFreeLogs");
      if (!Directory.Exists(str))
        Directory.CreateDirectory(str);
      File.AppendAllText(Path.Combine(str, "DiscordRpcError.txt"), $"[{DateTime.Now}] [{level}] {message}\n");
    }
    catch
    {
    }
  }

  public static void Initialize()
  {
    if (DiscordRpcManager._reconnectCts != null)
      return;
    DiscordRpcManager._reconnectCts = new CancellationTokenSource();
    DiscordRpcManager._startTimeUnix = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
    CancellationToken token = DiscordRpcManager._reconnectCts.Token;
    Task.Run((Func<Task>) (() =>
    {
      // ISSUE: variable of a compiler-generated type
      DiscordRpcManager.\u003CInitialize\u003Ec__AnonStorey6.\u003CInitialize\u003Ec__async5 stateMachine;
      // ISSUE: reference to a compiler-generated field
      stateMachine.\u003C\u003Ef__ref\u00246 = this;
      // ISSUE: reference to a compiler-generated field
      stateMachine.\u0024builder = AsyncTaskMethodBuilder.Create();
      // ISSUE: reference to a compiler-generated field
      ref AsyncTaskMethodBuilder local = ref stateMachine.\u0024builder;
      local.Start<DiscordRpcManager.\u003CInitialize\u003Ec__AnonStorey6.\u003CInitialize\u003Ec__async5>(ref stateMachine);
      return local.Task;
    }), token);
  }

  private static Task TryConnectAsync()
  {
    // ISSUE: variable of a compiler-generated type
    DiscordRpcManager.\u003CTryConnectAsync\u003Ec__async0 stateMachine;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder = AsyncTaskMethodBuilder.Create();
    // ISSUE: reference to a compiler-generated field
    ref AsyncTaskMethodBuilder local = ref stateMachine.\u0024builder;
    local.Start<DiscordRpcManager.\u003CTryConnectAsync\u003Ec__async0>(ref stateMachine);
    return local.Task;
  }

  public static void UpdatePresence(string state)
  {
    DiscordRpcManager.CurrentStateText = state;
    Task.Run((Func<Task>) (() =>
    {
      // ISSUE: variable of a compiler-generated type
      DiscordRpcManager.\u003CUpdatePresence\u003Ec__asyncA stateMachine;
      // ISSUE: reference to a compiler-generated field
      stateMachine.\u0024builder = AsyncTaskMethodBuilder.Create();
      // ISSUE: reference to a compiler-generated field
      ref AsyncTaskMethodBuilder local = ref stateMachine.\u0024builder;
      local.Start<DiscordRpcManager.\u003CUpdatePresence\u003Ec__asyncA>(ref stateMachine);
      return local.Task;
    }));
  }

  private static Task SendPresenceUpdateAsync()
  {
    // ISSUE: variable of a compiler-generated type
    DiscordRpcManager.\u003CSendPresenceUpdateAsync\u003Ec__async1 stateMachine;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder = AsyncTaskMethodBuilder.Create();
    // ISSUE: reference to a compiler-generated field
    ref AsyncTaskMethodBuilder local = ref stateMachine.\u0024builder;
    local.Start<DiscordRpcManager.\u003CSendPresenceUpdateAsync\u003Ec__async1>(ref stateMachine);
    return local.Task;
  }

  private static Task ReadLoopAsync(CancellationToken token)
  {
    // ISSUE: variable of a compiler-generated type
    DiscordRpcManager.\u003CReadLoopAsync\u003Ec__async2 stateMachine;
    // ISSUE: reference to a compiler-generated field
    stateMachine.token = token;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder = AsyncTaskMethodBuilder.Create();
    // ISSUE: reference to a compiler-generated field
    ref AsyncTaskMethodBuilder local = ref stateMachine.\u0024builder;
    local.Start<DiscordRpcManager.\u003CReadLoopAsync\u003Ec__async2>(ref stateMachine);
    return local.Task;
  }

  private static Task WriteFrameAsync(int op, string payload)
  {
    // ISSUE: variable of a compiler-generated type
    DiscordRpcManager.\u003CWriteFrameAsync\u003Ec__async3 stateMachine;
    // ISSUE: reference to a compiler-generated field
    stateMachine.payload = payload;
    // ISSUE: reference to a compiler-generated field
    stateMachine.op = op;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder = AsyncTaskMethodBuilder.Create();
    // ISSUE: reference to a compiler-generated field
    ref AsyncTaskMethodBuilder local = ref stateMachine.\u0024builder;
    local.Start<DiscordRpcManager.\u003CWriteFrameAsync\u003Ec__async3>(ref stateMachine);
    return local.Task;
  }

  private static Task<Tuple<int, string>> ReadFrameAsync(CancellationToken token)
  {
    // ISSUE: variable of a compiler-generated type
    DiscordRpcManager.\u003CReadFrameAsync\u003Ec__async4 stateMachine;
    // ISSUE: reference to a compiler-generated field
    stateMachine.token = token;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder = AsyncTaskMethodBuilder<Tuple<int, string>>.Create();
    // ISSUE: reference to a compiler-generated field
    ref AsyncTaskMethodBuilder<Tuple<int, string>> local = ref stateMachine.\u0024builder;
    local.Start<DiscordRpcManager.\u003CReadFrameAsync\u003Ec__async4>(ref stateMachine);
    return local.Task;
  }

  private static void ShutdownConnectionOnly()
  {
    try
    {
      if (DiscordRpcManager._readLoopCts != null)
        DiscordRpcManager._readLoopCts.Cancel();
    }
    catch
    {
    }
    try
    {
      if (DiscordRpcManager._readLoopCts != null)
        DiscordRpcManager._readLoopCts.Dispose();
    }
    catch
    {
    }
    DiscordRpcManager._readLoopCts = (CancellationTokenSource) null;
    NamedPipeClientStream pipeClientStream = (NamedPipeClientStream) null;
    lock (DiscordRpcManager._pipeLock)
    {
      pipeClientStream = DiscordRpcManager._pipe;
      DiscordRpcManager._pipe = (NamedPipeClientStream) null;
    }
    try
    {
      pipeClientStream?.Dispose();
    }
    catch
    {
    }
    DiscordRpcManager._isConnected = false;
  }

  public static void Shutdown()
  {
    try
    {
      if (DiscordRpcManager._reconnectCts != null)
        DiscordRpcManager._reconnectCts.Cancel();
    }
    catch
    {
    }
    try
    {
      if (DiscordRpcManager._reconnectCts != null)
        DiscordRpcManager._reconnectCts.Dispose();
    }
    catch
    {
    }
    DiscordRpcManager._reconnectCts = (CancellationTokenSource) null;
    DiscordRpcManager.ShutdownConnectionOnly();
    DiscordRpcManager.Log("INFO", "Conexão RPC encerrada completamente.");
  }
}
