﻿// Decompiled with JetBrains decompiler
// Type: nxr.NotificationType
// Assembly: ALECRIN_BYPASS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 740F77D7-0E85-4933-8B02-AA9B06E69548
// Assembly location: C:\Users\Systemov\Desktop\Release\Telapos Bypass.exe

#nullable disable
namespace nxr;

public enum NotificationType
{
  Apply,
  Success,
  Failed,
  NotFound,
  Error,
  Info,
}
