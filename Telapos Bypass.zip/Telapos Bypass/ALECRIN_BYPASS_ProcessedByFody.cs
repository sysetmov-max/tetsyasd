﻿// Decompiled with JetBrains decompiler
// Type: ALECRIN_BYPASS_ProcessedByFody
// Assembly: ALECRIN_BYPASS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 740F77D7-0E85-4933-8B02-AA9B06E69548
// Assembly location: C:\Users\Systemov\Desktop\Release\Telapos Bypass.exe

#nullable disable
internal class ALECRIN_BYPASS_ProcessedByFody
{
  internal const string FodyVersion = "6.8.2.0";
  internal const string Costura = "6.0.0";
}
