﻿// Decompiled with JetBrains decompiler
// Type: TELAPOS_UID_BYPASS.SplashForm
// Assembly: ALECRIN_BYPASS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 740F77D7-0E85-4933-8B02-AA9B06E69548
// Assembly location: C:\Users\Systemov\Desktop\Release\Telapos Bypass.exe

using Guna.UI2.WinForms;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

#nullable disable
namespace TELAPOS_UID_BYPASS;

public class SplashForm : Form
{
  private string folderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "mcn");
  private string dllPath;
  private string dllUrl = "https://raw.githubusercontent.com/mmijan330/FOR-IND-ALL/refs/heads/main/UIDBypassDll.dll";
  private float spinnerAngle;
  private Timer spinnerTimer;
  private IContainer components;
  private Guna2BorderlessForm guna2BorderlessForm1;
  private Guna2ProgressBar guna2ProgressBar1;
  private Label lblTitle;
  private Label lblStatus;
  private Guna2PictureBox guna2PictureBox1;
  private Panel panelLoader;

  public SplashForm()
  {
    this.InitializeComponent();
    this.dllPath = Path.Combine(this.folderPath, "telaposUIDBypassDll.dll");
    try
    {
      this.Icon = Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location);
    }
    catch
    {
    }
    this.spinnerTimer = new Timer();
    this.spinnerTimer.Interval = 15;
    this.spinnerTimer.Tick += (EventHandler) ((s, e) =>
    {
      this.spinnerAngle = (float) (((double) this.spinnerAngle + 5.0) % 360.0);
      this.panelLoader.Invalidate();
    });
    this.spinnerTimer.Start();
  }

  public bool DllLoaded { get; set; }

  [DllImport("kernel32.dll", SetLastError = true)]
  private static extern IntPtr LoadLibrary(string lpFileName);

  private void SplashForm_Load(object sender, EventArgs e)
  {
    // ISSUE: variable of a compiler-generated type
    SplashForm.\u003CSplashForm_Load\u003Ec__async0 stateMachine;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024this = this;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder = AsyncVoidMethodBuilder.Create();
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder.Start<SplashForm.\u003CSplashForm_Load\u003Ec__async0>(ref stateMachine);
  }

  private void panelLoader_Paint(object sender, PaintEventArgs e)
  {
    Graphics graphics = e.Graphics;
    graphics.SmoothingMode = SmoothingMode.AntiAlias;
    Rectangle rect1 = new Rectangle(2, 2, this.panelLoader.Width - 5, this.panelLoader.Height - 5);
    using (Pen pen = new Pen(Color.FromArgb(168, 85, 247), 3f))
    {
      pen.StartCap = LineCap.Round;
      pen.EndCap = LineCap.Round;
      graphics.DrawArc(pen, rect1, this.spinnerAngle, 140f);
    }
    Rectangle rect2 = new Rectangle(8, 8, this.panelLoader.Width - 17, this.panelLoader.Height - 17);
    using (Pen pen = new Pen(Color.FromArgb(192 /*0xC0*/, 0, (int) byte.MaxValue), 2f))
    {
      pen.StartCap = LineCap.Round;
      pen.EndCap = LineCap.Round;
      graphics.DrawArc(pen, rect2, (float) (-(double) this.spinnerAngle * 1.5), 100f);
    }
  }

  private Task DownloadFileAsync(string url, string destPath)
  {
    // ISSUE: variable of a compiler-generated type
    SplashForm.\u003CDownloadFileAsync\u003Ec__async1 stateMachine;
    // ISSUE: reference to a compiler-generated field
    stateMachine.url = url;
    // ISSUE: reference to a compiler-generated field
    stateMachine.destPath = destPath;
    // ISSUE: reference to a compiler-generated field
    stateMachine.\u0024builder = AsyncTaskMethodBuilder.Create();
    // ISSUE: reference to a compiler-generated field
    ref AsyncTaskMethodBuilder local = ref stateMachine.\u0024builder;
    local.Start<SplashForm.\u003CDownloadFileAsync\u003Ec__async1>(ref stateMachine);
    return local.Task;
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.components = (IContainer) new System.ComponentModel.Container();
    this.guna2BorderlessForm1 = new Guna2BorderlessForm(this.components);
    this.guna2ProgressBar1 = new Guna2ProgressBar();
    this.lblTitle = new Label();
    this.lblStatus = new Label();
    this.guna2PictureBox1 = new Guna2PictureBox();
    this.panelLoader = new Panel();
    ((ISupportInitialize) this.guna2PictureBox1).BeginInit();
    this.SuspendLayout();
    this.guna2BorderlessForm1.BorderRadius = 10;
    this.guna2BorderlessForm1.ContainerControl = (ContainerControl) this;
    this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6;
    this.guna2BorderlessForm1.ShadowColor = Color.FromArgb(40, 40, 45);
    this.guna2BorderlessForm1.TransparentWhileDrag = true;
    this.guna2ProgressBar1.BorderRadius = 3;
    this.guna2ProgressBar1.FillColor = Color.FromArgb(26, 26, 30);
    this.guna2ProgressBar1.Location = new Point(30, 135);
    this.guna2ProgressBar1.Name = "guna2ProgressBar1";
    this.guna2ProgressBar1.ProgressColor = Color.FromArgb(128 /*0x80*/, 0, (int) byte.MaxValue);
    this.guna2ProgressBar1.ProgressColor2 = Color.FromArgb(85, 0, 180);
    this.guna2ProgressBar1.Size = new Size(300, 6);
    this.guna2ProgressBar1.TabIndex = 0;
    this.guna2ProgressBar1.Text = "guna2ProgressBar1";
    this.guna2ProgressBar1.TextRenderingHint = TextRenderingHint.SystemDefault;
    this.lblTitle.AutoSize = true;
    this.lblTitle.Font = new Font("Segoe UI Semibold", 12f, FontStyle.Bold);
    this.lblTitle.ForeColor = Color.White;
    this.lblTitle.Location = new Point(130, 35);
    this.lblTitle.Name = "lblTitle";
    this.lblTitle.Size = new Size(183, 21);
    this.lblTitle.TabIndex = 1;
    this.lblTitle.Text = "TELAPOS BYPASS";
    this.lblStatus.AutoSize = true;
    this.lblStatus.Font = new Font("Segoe UI", 9f);
    this.lblStatus.ForeColor = Color.FromArgb(140, 140, 150);
    this.lblStatus.Location = new Point(27, 112 /*0x70*/);
    this.lblStatus.Name = "lblStatus";
    this.lblStatus.Size = new Size(130, 15);
    this.lblStatus.TabIndex = 2;
    this.lblStatus.Text = "Verificando atualizações...";
    this.guna2PictureBox1.ImageRotate = 0.0f;
    this.guna2PictureBox1.Location = new Point(30, 20);
    this.guna2PictureBox1.Name = "guna2PictureBox1";
    this.guna2PictureBox1.Size = new Size(80 /*0x50*/, 80 /*0x50*/);
    this.guna2PictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
    this.guna2PictureBox1.TabIndex = 3;
    this.guna2PictureBox1.TabStop = false;
    this.panelLoader.Location = new Point(201, 63 /*0x3F*/);
    this.panelLoader.Name = "panelLoader";
    this.panelLoader.Size = new Size(40, 40);
    this.panelLoader.TabIndex = 5;
    this.panelLoader.Paint += new PaintEventHandler(this.panelLoader_Paint);
    this.AutoScaleMode = AutoScaleMode.None;
    this.BackColor = Color.FromArgb(18, 18, 20);
    this.ClientSize = new Size(360, 180);
    this.Controls.Add((Control) this.panelLoader);
    this.Controls.Add((Control) this.guna2PictureBox1);
    this.Controls.Add((Control) this.lblStatus);
    this.Controls.Add((Control) this.lblTitle);
    this.Controls.Add((Control) this.guna2ProgressBar1);
    this.FormBorderStyle = FormBorderStyle.None;
    this.Name = nameof (SplashForm);
    this.StartPosition = FormStartPosition.CenterScreen;
    this.Text = "Atualização - Telapos Bypass";
    this.Load += new EventHandler(this.SplashForm_Load);
    ((ISupportInitialize) this.guna2PictureBox1).EndInit();
    this.ResumeLayout(false);
    this.PerformLayout();
  }
}
