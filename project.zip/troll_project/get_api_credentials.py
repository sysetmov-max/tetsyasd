"""
Скрипт логинится на my.telegram.org (не через Telethon, а через обычный
веб-логин, как ручками в браузере) и достаёт/создаёт api_id + api_hash.

Флоу:
1. Вводишь номер телефона (с кодом страны, например +380...)
2. На телефон/в Telegram приходит код подтверждения
3. Вводишь код -> скрипт логинится и получает сессионные куки
4. Заходит на /apps:
   - если приложение уже создано -> переименовывает в APP_TITLE и выводит api_id/api_hash
   - если приложения нет -> создаёт новое с именем APP_TITLE и выводит данные

ВАЖНО: это работа с неофициальной HTML-страницей Telegram (my.telegram.org),
у нее нет публичного API. Если Telegram поменяет вёрстку формы - регулярки
ниже могут перестать матчиться. В таком случае открой DevTools -> Network
на my.telegram.org и посмотри реальные названия полей формы (input name=...).
"""

import re
import sys
import requests

BASE_URL = "https://my.telegram.org"
APP_TITLE = "BotRekitaiPlaga"
APP_SHORTNAME = "botrekitaiplaga"  # только латиница/цифры, без пробелов

session = requests.Session()
session.headers.update({
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
})


def send_code(phone: str) -> str:
    """
    Отправляем номер на /auth/send_password.
    random_hash приходит именно в JSON-ответе этого запроса, а не в HTML страницы /auth -
    поэтому отдельно его скрапить не нужно.
    """
    resp = session.post(f"{BASE_URL}/auth/send_password", data={"phone": phone})
    try:
        data = resp.json()
    except ValueError:
        _dump_debug_html("send_password_response.html", resp.text)
        raise RuntimeError(
            "Ответ от /auth/send_password пришёл не в JSON, а как HTML "
            "(дампнул в send_password_response.html - глянь что там, "
            "возможно номер не в том формате или капча/бан по IP)."
        )

    if data.get("error"):
        raise RuntimeError(f"Ошибка при отправке кода: {data}")

    random_hash = data.get("random_hash")
    if not random_hash:
        raise RuntimeError(f"В ответе нет random_hash, вот весь ответ: {data}")

    print("Код отправлен. Проверь Telegram.")
    return random_hash


def _dump_debug_html(filename: str, html: str) -> None:
    with open(filename, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"(debug) сохранил HTML в {filename} для ручной проверки")


def login(phone: str, random_hash: str, code: str) -> None:
    resp = session.post(f"{BASE_URL}/auth/login", data={
        "phone": phone,
        "random_hash": random_hash,
        "password": code,  # тут именно поле "password", хотя это код из тг
    })
    cookies = session.cookies.get_dict()
    if "stel_token" not in cookies and "stel_ssid" not in cookies:
        _dump_debug_html("login_response.html", resp.text)
        raise RuntimeError(
            "Похоже, логин не удался (нет сессионных кук). "
            "Дампнул ответ в login_response.html - проверь код/номер, "
            "либо там капча/ошибка от Telegram."
        )
    print("Успешный логин.")


def get_apps_page() -> str:
    resp = session.get(f"{BASE_URL}/apps")
    return resp.text


def extract_hidden_hash(html: str) -> str:
    """Скрытое поле hash из формы app_edit_form - нужно для /apps/save."""
    match = re.search(r'name="hash"\s+value="([a-f0-9]+)"', html)
    return match.group(1) if match else ""


def extract_existing_credentials(html: str):
    """Если приложение уже создано - на странице /apps будут готовые api_id/api_hash."""
    api_id_match = re.search(r'App api_id:.*?<strong>(\d+)</strong>', html, re.DOTALL)
    api_hash_match = re.search(
        r'App api_hash:.*?uneditable-input"[^>]*>\s*([a-f0-9]{32})\s*</span>', html, re.DOTALL
    )
    if api_id_match and api_hash_match:
        return api_id_match.group(1), api_hash_match.group(1)
    return None


def create_app(hidden_hash: str):
    resp = session.post(f"{BASE_URL}/apps/create", data={
        "hash": hidden_hash,
        "app_title": APP_TITLE,
        "app_shortname": APP_SHORTNAME,
        "app_url": "",
        "app_platform": "web",
        "app_desc": "",
    })
    return resp.text


def rename_app(hidden_hash: str) -> None:
    """Переименовываем существующее приложение через /apps/save (тот же эндпоинт, что дергает кнопка Save changes)."""
    resp = session.post(f"{BASE_URL}/apps/save", data={
        "hash": hidden_hash,
        "app_title": APP_TITLE,
        "app_shortname": APP_SHORTNAME,
    })
    body = resp.text.strip()
    if body:
        # эндпоинт при успехе обычно отвечает пусто, непустой ответ - вероятно текст ошибки
        print(f"(предупреждение) /apps/save вернул непустой ответ, возможно ошибка: {body[:300]}")


def main():
    phone = input("Введи номер телефона (с кодом страны, напр. +380123456789): ").strip()

    random_hash = send_code(phone)

    code = input("Введи код, который пришёл в Telegram: ").strip()
    login(phone, random_hash, code)

    html = get_apps_page()
    existing = extract_existing_credentials(html)
    hidden_hash = extract_hidden_hash(html)

    if not existing and not hidden_hash:
        # Не смогли распарсить вообще ничего полезного - дампим страницу для разбора
        _dump_debug_html("apps_page.html", html)

    if existing:
        api_id, api_hash = existing
        print(f"Приложение уже существует, переименовываю в '{APP_TITLE}'...")
        rename_app(hidden_hash)
        result = (api_id, api_hash)  # api_id/api_hash не меняются при переименовании
    else:
        print(f"Приложения нет, создаю новое '{APP_TITLE}'...")
        html_after = create_app(hidden_hash)
        result = extract_existing_credentials(html_after)
        if not result:
            _dump_debug_html("apps_after.html", html_after)

    if not result:
        print("Не удалось автоматически распарсить api_id/api_hash со страницы.")
        print("Дампнул HTML в apps_page.html / apps_after.html - пришли мне их содержимое, поправлю регулярки.")
        sys.exit(1)

    api_id, api_hash = result
    print("\n=== Готово ===")
    print(f"api_id:   {api_id}")
    print(f"api_hash: {api_hash}")


if __name__ == "__main__":
    main()