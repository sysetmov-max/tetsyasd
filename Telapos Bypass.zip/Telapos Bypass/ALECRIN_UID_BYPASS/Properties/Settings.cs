﻿// Decompiled with JetBrains decompiler
// Type: ALECRIN_UID_BYPASS.Properties.Settings
// Assembly: ALECRIN_BYPASS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 740F77D7-0E85-4933-8B02-AA9B06E69548
// Assembly location: C:\Users\Systemov\Desktop\Release\Telapos Bypass.exe

using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

#nullable disable
namespace ALECRIN_UID_BYPASS.Properties;

[CompilerGenerated]
[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "18.7.0.0")]
internal sealed class Settings : ApplicationSettingsBase
{
  private static Settings defaultInstance = (Settings) SettingsBase.Synchronized((SettingsBase) new Settings());

  public static Settings Default => Settings.defaultInstance;
}
