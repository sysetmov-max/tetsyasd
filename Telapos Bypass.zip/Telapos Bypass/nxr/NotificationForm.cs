﻿// Decompiled with JetBrains decompiler
// Type: nxr.NotificationForm
// Assembly: ALECRIN_BYPASS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 740F77D7-0E85-4933-8B02-AA9B06E69548
// Assembly location: C:\Users\Systemov\Desktop\Release\Telapos Bypass.exe

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

#nullable disable
namespace nxr;

public class NotificationForm : Form
{
  private static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);
  private const uint TOPMOST_FLAGS = 67;
  private string _title;
  private string _msg;
  private string iconSymbol;
  private int _duration;
  private int _remain;
  private int glowPulse;
  private bool closing;
  private bool glowUp = true;
  private Color accent;
  private Color bg = Color.FromArgb(18, 10, 26);
  private Timer timer;
  private static List<NotificationForm> activeNotifications = new List<NotificationForm>();
  private float borderOffset;
  private Image logoImage;
  public static bool EnableSound = false;

  public NotificationForm(string title, string msg, int duration, NotificationType type)
  {
    NotificationForm notificationForm = this;
    this._title = title;
    this._msg = msg;
    this._duration = duration;
    this._remain = duration;
    this.SetType(type);
    try
    {
      using (Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("ALECRIN_UID_BYPASS.logo.png"))
      {
        if (manifestResourceStream != null)
          this.logoImage = Image.FromStream(manifestResourceStream);
      }
    }
    catch
    {
    }
    this.Size = new Size(340, 68);
    this.FormBorderStyle = FormBorderStyle.None;
    this.StartPosition = FormStartPosition.Manual;
    this.ShowInTaskbar = false;
    this.DoubleBuffered = true;
    this.BackColor = this.bg;
    this.Opacity = 0.65;
    this.Region = Region.FromHrgn(NotificationForm.CreateRoundRectRgn(0, 0, 340, 68, 14, 14));
    this.timer = new Timer() { Interval = 10 };
    this.timer.Tick += (EventHandler) ((s, e) => notificationForm.HandleTick());
    if (!NotificationForm.EnableSound)
      return;
    Task.Run((Action) (() => notificationForm.PlayMatchingSound(type)));
  }

  [DllImport("user32.dll")]
  private static extern bool SetWindowPos(
    IntPtr hWnd,
    IntPtr hWndInsertAfter,
    int X,
    int Y,
    int cx,
    int cy,
    uint uFlags);

  [DllImport("Gdi32.dll")]
  private static extern IntPtr CreateRoundRectRgn(
    int nLeftRect,
    int nTopRect,
    int nRightRect,
    int nBottomRect,
    int nWidthEllipse,
    int nHeightEllipse);

  private void InitializeComponent()
  {
    this.SuspendLayout();
    this.ClientSize = new Size(284, 261);
    this.Name = nameof (NotificationForm);
    this.Load += new EventHandler(this.NotificationForm_Load);
    this.ResumeLayout(false);
  }

  private void NotificationForm_Load(object sender, EventArgs e)
  {
  }

  private void SetType(NotificationType type)
  {
    this.accent = Color.FromArgb(168, 85, 247);
    switch (type)
    {
      case NotificationType.Apply:
        this.iconSymbol = "✦";
        break;
      case NotificationType.Success:
        this.iconSymbol = "✓";
        break;
      case NotificationType.Failed:
      case NotificationType.Error:
        this.iconSymbol = "✕";
        break;
      case NotificationType.NotFound:
        this.iconSymbol = "!";
        break;
      case NotificationType.Info:
        this.iconSymbol = "ℹ";
        break;
    }
  }

  private void PlayMatchingSound(NotificationType type)
  {
    try
    {
      switch (type)
      {
        case NotificationType.Success:
          Console.Beep(1200, 100);
          Console.Beep(1500, 100);
          break;
        case NotificationType.Failed:
          Console.Beep(600, 150);
          Console.Beep(400, 150);
          break;
        case NotificationType.Error:
          Console.Beep(400, 400);
          break;
        default:
          Console.Beep(900, 150);
          break;
      }
    }
    catch
    {
    }
  }

  protected override void OnPaint(PaintEventArgs e)
  {
    Graphics graphics = e.Graphics;
    graphics.SmoothingMode = SmoothingMode.AntiAlias;
    graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
    using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(14, 8, 22)))
      graphics.FillRectangle((Brush) solidBrush, this.ClientRectangle);
    using (GraphicsPath path = new GraphicsPath())
    {
      int num = 14;
      path.AddArc(0, 0, num, num, 180f, 90f);
      path.AddArc(this.Width - num - 1, 0, num, num, 270f, 90f);
      path.AddArc(this.Width - num - 1, this.Height - num - 1, num, num, 0.0f, 90f);
      path.AddArc(0, this.Height - num - 1, num, num, 90f, 90f);
      path.CloseAllFigures();
      using (LinearGradientBrush linearGradientBrush = new LinearGradientBrush(new Rectangle(0, 0, this.Width, this.Height), Color.FromArgb(168, 85, 247), Color.FromArgb(236, 72, 153), this.borderOffset % 360f))
      {
        linearGradientBrush.InterpolationColors = new ColorBlend(4)
        {
          Colors = new Color[4]
          {
            Color.FromArgb(168, 85, 247),
            Color.FromArgb(236, 72, 153),
            Color.FromArgb(99, 102, 241),
            Color.FromArgb(168, 85, 247)
          },
          Positions = new float[4]{ 0.0f, 0.33f, 0.66f, 1f }
        };
        using (Pen pen = new Pen((Brush) linearGradientBrush, 1.8f))
          graphics.DrawPath(pen, path);
      }
    }
    using (GraphicsPath path = new GraphicsPath())
    {
      path.AddRectangle(new Rectangle(-10, -10, this.Width + 20, this.Height + 20));
      using (PathGradientBrush pathGradientBrush = new PathGradientBrush(path))
      {
        pathGradientBrush.CenterColor = Color.FromArgb(12 + this.glowPulse, this.accent);
        pathGradientBrush.SurroundColors = new Color[1]
        {
          Color.Transparent
        };
        graphics.FillPath((Brush) pathGradientBrush, path);
      }
    }
    Rectangle rect = new Rectangle(18, 18, 32 /*0x20*/, 32 /*0x20*/);
    if (this.logoImage != null)
    {
      graphics.DrawImage(this.logoImage, rect);
    }
    else
    {
      using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(20, this.accent)))
        graphics.FillEllipse((Brush) solidBrush, rect);
      using (Pen pen = new Pen(this.accent, 1.5f))
        graphics.DrawEllipse(pen, rect);
      if (this.iconSymbol == "✓")
      {
        using (Pen pen = new Pen(this.accent, 2f))
        {
          pen.StartCap = LineCap.Round;
          pen.EndCap = LineCap.Round;
          pen.LineJoin = LineJoin.Round;
          graphics.DrawLines(pen, new PointF[3]
          {
            new PointF((float) (rect.X + 10), (float) (rect.Y + 16 /*0x10*/)),
            new PointF((float) (rect.X + 15), (float) (rect.Y + 21)),
            new PointF((float) (rect.X + 22), (float) (rect.Y + 11))
          });
        }
      }
      else if (this.iconSymbol == "✕" || this.iconSymbol == "✖")
      {
        using (Pen pen = new Pen(this.accent, 2f))
        {
          pen.StartCap = LineCap.Round;
          pen.EndCap = LineCap.Round;
          graphics.DrawLine(pen, rect.X + 11, rect.Y + 11, rect.X + 21, rect.Y + 21);
          graphics.DrawLine(pen, rect.X + 21, rect.Y + 11, rect.X + 11, rect.Y + 21);
        }
      }
      else
      {
        using (Font font = new Font("Segoe UI", 11f, FontStyle.Bold))
        {
          using (SolidBrush solidBrush = new SolidBrush(this.accent))
          {
            SizeF sizeF = graphics.MeasureString(this.iconSymbol, font);
            graphics.DrawString(this.iconSymbol, font, (Brush) solidBrush, (float) rect.X + (float) ((32.0 - (double) sizeF.Width) / 2.0), (float) rect.Y + (float) ((32.0 - (double) sizeF.Height) / 2.0));
          }
        }
      }
    }
    using (Font font = new Font("Segoe UI Semibold", 9.75f, FontStyle.Bold))
      graphics.DrawString(this._title, font, Brushes.White, 64f, 13f);
    using (Font font = new Font("Segoe UI", 8.25f))
    {
      using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(160 /*0xA0*/, 160 /*0xA0*/, 175)))
        graphics.DrawString(this._msg, font, (Brush) solidBrush, new RectangleF(64f, 33f, 260f, 25f));
    }
    if (this.closing || this._duration <= 0)
      return;
    int width = (int) (340.0 * ((double) this._remain / (double) this._duration));
    if (width <= 0)
      return;
    using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(180, this.accent)))
      graphics.FillRectangle((Brush) solidBrush, 0, 65, width, 3);
  }

  private void HandleTick()
  {
    this.borderOffset += 3.5f;
    if (this.glowUp)
      ++this.glowPulse;
    else
      --this.glowPulse;
    if (this.glowPulse > 25)
      this.glowUp = false;
    else if (this.glowPulse < 3)
      this.glowUp = true;
    if (!this.closing)
    {
      this._remain -= 10;
      if (this._remain <= 0)
        this.closing = true;
      this.Invalidate();
    }
    int num1 = Screen.PrimaryScreen.WorkingArea.Height - 78 * (NotificationForm.activeNotifications.IndexOf(this) + 1) - 10;
    int num2 = Screen.PrimaryScreen.WorkingArea.Width - 340 - 15;
    if (this.closing)
    {
      this.Opacity -= 0.08;
      this.Left += 4;
      if (this.Opacity > 0.0)
        return;
      this.timer.Stop();
      NotificationForm.activeNotifications.Remove(this);
      this.Close();
    }
    else
    {
      this.Left = num2;
      if ((double) Math.Abs(this.Top - num1) > 0.5)
        this.Top -= (this.Top - num1) / 6;
      if (this.Opacity >= 0.65)
        return;
      this.Opacity += 0.1;
    }
  }

  public static void ShowNotification(
    string title,
    string msg,
    NotificationType type,
    int duration = 3000)
  {
    if (Application.OpenForms.Count > 0)
    {
      if (Application.OpenForms[0].InvokeRequired)
      {
        try
        {
          Application.OpenForms[0].Invoke((Delegate) (() => NotificationForm.ShowNotification(title, msg, type, duration)));
          return;
        }
        catch
        {
          return;
        }
      }
    }
    NotificationForm notificationForm = new NotificationForm(title, msg, duration, type);
    NotificationForm.activeNotifications.Add(notificationForm);
    notificationForm.Opacity = 0.0;
    notificationForm.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - 340, Screen.PrimaryScreen.WorkingArea.Height);
    notificationForm.Show();
    NotificationForm.SetWindowPos(notificationForm.Handle, NotificationForm.HWND_TOPMOST, 0, 0, 0, 0, 67U);
    notificationForm.timer.Start();
  }

  protected override void OnClick(EventArgs e) => this.closing = true;
}
